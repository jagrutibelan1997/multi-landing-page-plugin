=== Landing Page Manager ===
Contributors: jagrutibbelan
Tags: landing page, homepage, lead generation, business, marketing
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 3.1.0
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Turn your WordPress homepage into a high-converting landing page. 4 variants: Yoga, Construction, Hospital, Jewellery. Manage content and leads from the dashboard.

== Description ==

Landing Page Manager replaces your WordPress homepage with a fully editable, high-converting landing page. Choose from four professionally designed variants and customise all content — text, images, contact info, and logo — directly from the WordPress admin dashboard.

**Features:**

* 4 ready-made landing page variants: Yoga, Construction, Hospital, Jewellery
* Edit all content from your WordPress dashboard — no coding needed
* Logo image upload with WordPress Media Library integration
* Image size recommendations displayed directly in the admin form
* Contact form with lead capture — submissions saved to your dashboard
* Leads management page with All / New / Read filter tabs and pagination
* Leads are scoped to the active template — only relevant submissions are shown
* Automatic email notification on every new lead
* Honeypot + rate limiting to block contact form spam
* Inactive template menus are visually dimmed in the sidebar
* One-click activation — overrides your homepage instantly
* Mobile-responsive, accessible, and SEO-friendly output
* Clean uninstall — all data removed when plugin is deleted

== Installation ==

1. Upload the `landing-page-manager` folder to the `/wp-content/plugins/` directory, or install via the WordPress Plugins screen directly.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Go to **Landing Page → Settings** and choose your variant (Yoga, Construction, Hospital, or Jewellery).
4. Go to the content page for your chosen variant and fill in your site name, logo, hero text, and contact details.
5. Your homepage will immediately display the landing page.

== Frequently Asked Questions ==

= Will this affect the rest of my site? =

No. The plugin only overrides your homepage (front page). All other WordPress pages, posts, and templates remain unchanged.

= How do I switch between templates? =

Go to **Landing Page → Settings**, select a different variant, and click Save. The change takes effect immediately.

= Where do contact form submissions go? =

All submissions are saved to **Landing Page → Leads** in your dashboard. Only leads from the currently active template are shown. You will also receive an email notification at your WordPress admin email address for each new submission.

= Can I use my own logo? =

Yes. Go to the content editing page for your active variant, scroll to the Logo section, and either upload a logo using the WordPress Media Library or paste any image URL. Recommended size: 174 × 53 px. You can also set a custom display name to appear next to the logo.

= What image sizes should I use? =

* **Logo**: 174 × 53 px — transparent PNG or SVG recommended
* **Hero background**: 1920 × 1080 px — full-width landscape, high contrast
* **About section**: 560 × 420 px — portrait or landscape photo

These recommended sizes are also shown directly in the admin forms next to each image field.

= What happens to my leads if I deactivate the plugin? =

The leads database table and all settings are preserved when you deactivate the plugin. Only when you completely delete (uninstall) the plugin will all data be removed.

= Is the contact form protected against spam? =

Yes. Every submission is protected by a WordPress nonce, a honeypot hidden field, and an IP-based rate limit of one submission per 60 seconds.

== Screenshots ==

1. Dashboard overview showing active variant and new lead count.
2. Content editing form with hero, about, and image size hints.
3. Logo upload section with WordPress Media Library picker.
4. Leads management page with All / New / Read filter tabs.
5. Frontend yoga landing page example.
6. Success popup shown after contact form submission.

== Changelog ==

= 3.1.0 =
* Added Leads management system — contact form submissions saved to dashboard
* Added logo image and display name support per variant (WP Media Library integration)
* Added two new templates: Hospital and Jewellery
* Added image size recommendations in admin forms
* Added WordPress Media Library pickers for all image fields
* Added success popup modal on contact form submission (shows once, clears on refresh)
* Added honeypot and IP-based rate limiting to the contact form
* Inactive template menus are now visually dimmed and non-clickable in the sidebar
* Leads page now scoped to active template only
* Hardened all admin handlers: nonces, capability checks, input sanitization
* Added uninstall.php for clean data removal

= 1.0.0 =
* Initial release with Yoga and Construction variants

== Upgrade Notice ==

= 3.1.0 =
Major update: adds Leads CRM, logo management, two new variants (Hospital, Jewellery), spam protection, and security hardening. Safe to upgrade — existing content settings are preserved.
