<?php
/**
 * Construction Landing Page Template
 * $data   — content array from config.php (construction key)
 * $config — full config array
 */
defined( 'ABSPATH' ) || exit;

$status = isset( $_GET['lpm_status'] ) ? sanitize_key( $_GET['lpm_status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="<?php echo esc_attr( $data['hero']['subheading'] ); ?>">
  <title><?php echo esc_html( $data['site_name'] . ' — ' . $data['tagline'] ); ?></title>
  <?php wp_head(); ?>
</head>
<body class="lpm-page lpm-construction" data-theme="dark">

<!-- ═══ NAVIGATION ═══ -->
<header class="lpm-nav" role="banner">
  <div class="lpm-wrap lpm-nav__inner">
    <a class="lpm-nav__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
      <?php if ( ! empty( $data['logo_image'] ) ) : ?>
        <img src="<?php echo esc_url( $data['logo_image'] ); ?>" alt="<?php echo esc_attr( $data['logo_text'] ?: $data['site_name'] ); ?>" class="lpm-nav__logo-img">
        <?php if ( ! empty( $data['logo_text'] ) || ! empty( $data['site_name'] ) ) : ?>
          <span class="lpm-nav__logo-name"><?php echo esc_html( $data['logo_text'] ?: $data['site_name'] ); ?></span>
        <?php endif; ?>
      <?php else : ?>
        🏗️ <?php echo esc_html( $data['logo_text'] ?: $data['site_name'] ); ?>
      <?php endif; ?>
    </a>

    <div class="lpm-nav__right">
      <nav class="lpm-nav__links" id="lpm-nav-menu" role="navigation">
        <?php foreach ( $data['nav'] as $link ) : ?>
          <a href="<?php echo esc_attr( $link['href'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a>
        <?php endforeach; ?>
        <a href="#contact" class="lpm-btn lpm-btn--primary lpm-btn--sm">
          <?php echo esc_html( $data['hero']['cta_text'] ); ?>
        </a>
      </nav>

      <button class="lpm-theme-toggle" aria-label="Toggle theme">🌙</button>

      <button
        class="lpm-nav__toggle"
        aria-controls="lpm-nav-menu"
        aria-expanded="false"
        aria-label="<?php esc_attr_e( 'Toggle navigation', 'landing-page-manager' ); ?>"
      >
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</header>

<!-- ═══ HERO ═══ -->
<section
  class="lpm-hero"
  style="background-image: url('<?php echo esc_url( $data['hero']['bg_image'] ); ?>')"
  aria-label="Hero"
>
  <div class="lpm-hero__overlay" aria-hidden="true"></div>
  <div class="lpm-wrap lpm-hero__content">
    <span class="lpm-hero__eyebrow lpm-reveal"><?php echo esc_html( $data['hero']['eyebrow'] ); ?></span>
    <h1 class="lpm-hero__title lpm-reveal lpm-reveal--delay-1"><?php echo esc_html( $data['hero']['headline'] ); ?></h1>
    <p class="lpm-hero__sub lpm-reveal lpm-reveal--delay-2"><?php echo esc_html( $data['hero']['subheading'] ); ?></p>
    <div class="lpm-hero__ctas lpm-reveal lpm-reveal--delay-3">
      <a href="<?php echo esc_attr( $data['hero']['cta_url'] ); ?>" class="lpm-btn lpm-btn--primary lpm-btn--lg">
        <?php echo esc_html( $data['hero']['cta_text'] ); ?>
      </a>
      <a href="<?php echo esc_attr( $data['hero']['cta2_url'] ); ?>" class="lpm-btn lpm-btn--ghost lpm-btn--lg">
        <?php echo esc_html( $data['hero']['cta2_text'] ); ?>
      </a>
    </div>
  </div>
  <div class="lpm-scroll-hint" aria-hidden="true">
    <div class="lpm-scroll-hint__arrow"></div>
  </div>
</section>

<!-- ═══ STATS ═══ -->
<div class="lpm-stats" aria-label="Key statistics">
  <div class="lpm-wrap lpm-stats__inner">
    <?php foreach ( $data['about']['stats'] as $stat ) : ?>
      <div class="lpm-reveal">
        <strong class="lpm-stat__value"><?php echo esc_html( $stat['value'] ); ?></strong>
        <span class="lpm-stat__label"><?php echo esc_html( $stat['label'] ); ?></span>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- ═══ ABOUT ═══ -->
<section class="lpm-section lpm-about" id="about" aria-labelledby="about-heading">
  <div class="lpm-orb lpm-orb--1" aria-hidden="true"></div>
  <div class="lpm-wrap lpm-about__inner">
    <div class="lpm-about__img-wrap lpm-reveal">
      <img
        class="lpm-about__img"
        src="<?php echo esc_url( $data['about']['image'] ); ?>"
        alt="<?php echo esc_attr( $data['about']['heading'] ); ?>"
        loading="lazy" width="560" height="420"
      >
      <div class="lpm-about__img-badge">
        <strong>20+</strong>
        Years Experience
      </div>
    </div>

    <div class="lpm-about__text">
      <h2 id="about-heading" class="lpm-section__title lpm-reveal" style="text-align:left;">
        <?php echo esc_html( $data['about']['heading'] ); ?>
      </h2>
      <p class="lpm-about__lead lpm-reveal lpm-reveal--delay-1"><?php echo esc_html( $data['about']['lead'] ); ?></p>
      <p class="lpm-reveal lpm-reveal--delay-2"><?php echo esc_html( $data['about']['text'] ); ?></p>

      <div class="lpm-about__stats lpm-reveal lpm-reveal--delay-2">
        <?php foreach ( $data['about']['stats'] as $stat ) : ?>
          <div>
            <strong class="lpm-about__stat-value"><?php echo esc_html( $stat['value'] ); ?></strong>
            <span class="lpm-about__stat-label"><?php echo esc_html( $stat['label'] ); ?></span>
          </div>
        <?php endforeach; ?>
      </div>

      <a href="#contact" class="lpm-btn lpm-btn--outline lpm-reveal lpm-reveal--delay-3">Request a Quote →</a>
    </div>
  </div>
</section>

<!-- ═══ SERVICES ═══ -->
<section class="lpm-section lpm-section--alt" id="classes" aria-labelledby="services-heading">
  <div class="lpm-orb lpm-orb--2" aria-hidden="true"></div>
  <div class="lpm-wrap">
    <div class="lpm-section__header">
      <span class="lpm-section__badge lpm-reveal">🔨 Services</span>
      <h2 id="services-heading" class="lpm-section__title lpm-reveal lpm-reveal--delay-1">
        <?php echo esc_html( $data['classes']['heading'] ); ?>
      </h2>
      <p class="lpm-section__sub lpm-reveal lpm-reveal--delay-2">
        <?php echo esc_html( $data['classes']['subtext'] ); ?>
      </p>
    </div>

    <div class="lpm-grid lpm-grid--3">
      <?php foreach ( $data['classes']['items'] as $i => $item ) : ?>
        <article class="lpm-card lpm-card--service lpm-reveal lpm-reveal--delay-<?php echo esc_attr( $i + 1 ); ?>">
          <img
            src="<?php echo esc_url( $item['image'] ); ?>"
            alt="<?php echo esc_attr( $item['name'] ); ?>"
            loading="lazy" width="400" height="220"
          >
          <div class="lpm-card__body">
            <span class="lpm-card__badge"><?php echo esc_html( $item['level'] ); ?></span>
            <h3><?php echo esc_html( $item['name'] ); ?></h3>
            <p class="lpm-card__meta">📅 <?php echo esc_html( $item['time'] ); ?></p>
            <p class="lpm-card__desc"><?php echo esc_html( $item['desc'] ); ?></p>
            <a href="#contact" class="lpm-btn lpm-btn--outline lpm-btn--sm">Get a Quote</a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══ WHY CHOOSE US ═══ -->
<section class="lpm-section" id="benefits" aria-labelledby="benefits-heading">
  <div class="lpm-wrap">
    <div class="lpm-section__header">
      <span class="lpm-section__badge lpm-reveal">⭐ Why Us</span>
      <h2 id="benefits-heading" class="lpm-section__title lpm-reveal lpm-reveal--delay-1">
        <?php echo esc_html( $data['benefits']['heading'] ); ?>
      </h2>
      <p class="lpm-section__sub lpm-reveal lpm-reveal--delay-2">
        <?php echo esc_html( $data['benefits']['subtext'] ); ?>
      </p>
    </div>

    <div class="lpm-grid lpm-grid--4">
      <?php foreach ( $data['benefits']['items'] as $i => $item ) : ?>
        <div class="lpm-card lpm-card--feature lpm-reveal lpm-reveal--delay-<?php echo esc_attr( $i + 1 ); ?>">
          <span class="lpm-card__icon" aria-hidden="true"><?php echo esc_html( $item['icon'] ); ?></span>
          <h3><?php echo esc_html( $item['title'] ); ?></h3>
          <p><?php echo esc_html( $item['text'] ); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══ TESTIMONIALS ═══ -->
<section class="lpm-section lpm-section--alt" id="testimonials" aria-labelledby="testi-heading">
  <div class="lpm-wrap">
    <div class="lpm-section__header">
      <span class="lpm-section__badge lpm-reveal">💬 Testimonials</span>
      <h2 id="testi-heading" class="lpm-section__title lpm-reveal lpm-reveal--delay-1">
        <?php echo esc_html( $data['testimonials']['heading'] ); ?>
      </h2>
      <p class="lpm-section__sub lpm-reveal lpm-reveal--delay-2">
        <?php echo esc_html( $data['testimonials']['subtext'] ); ?>
      </p>
    </div>

    <div class="lpm-grid lpm-grid--3">
      <?php foreach ( $data['testimonials']['items'] as $i => $item ) : ?>
        <blockquote class="lpm-card lpm-card--testi lpm-reveal lpm-reveal--delay-<?php echo esc_attr( $i + 1 ); ?>">
          <div class="lpm-testi__stars" aria-label="5 stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
          <p class="lpm-testi__quote"><?php echo esc_html( $item['quote'] ); ?></p>
          <footer class="lpm-testi__author">
            <img class="lpm-testi__avatar" src="<?php echo esc_url( $item['avatar'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" loading="lazy" width="44" height="44">
            <div>
              <strong class="lpm-testi__name"><?php echo esc_html( $item['name'] ); ?></strong>
              <span class="lpm-testi__role"><?php echo esc_html( $item['role'] ); ?></span>
            </div>
          </footer>
        </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══ CONTACT ═══ -->
<section class="lpm-section lpm-contact" id="contact" aria-labelledby="contact-heading">
  <div class="lpm-wrap lpm-contact__inner">
    <div>
      <h2 id="contact-heading" class="lpm-contact__info-heading lpm-reveal">
        <?php echo esc_html( $data['contact']['heading'] ); ?>
      </h2>
      <p class="lpm-contact__info-sub lpm-reveal lpm-reveal--delay-1">
        <?php echo esc_html( $data['contact']['subtext'] ); ?>
      </p>
      <ul class="lpm-contact__details lpm-reveal lpm-reveal--delay-2">
        <li><span>📍</span><span><?php echo esc_html( $data['contact']['address'] ); ?></span></li>
        <li><span>✉️</span><span><a href="mailto:<?php echo esc_attr( $data['contact']['email'] ); ?>" style="color:inherit"><?php echo esc_html( $data['contact']['email'] ); ?></a></span></li>
        <li><span>📞</span><span><a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $data['contact']['phone'] ) ); ?>" style="color:inherit"><?php echo esc_html( $data['contact']['phone'] ); ?></a></span></li>
        <li><span>🕐</span><span><?php echo esc_html( $data['contact']['hours'] ); ?></span></li>
      </ul>
    </div>

    <form class="lpm-form lpm-reveal lpm-reveal--delay-1" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
      <input type="hidden" name="action" value="lpm_contact">
      <input type="hidden" name="lpm_variant" value="<?php echo esc_attr( $config['site_type'] ?? 'construction' ); ?>">
      <?php wp_nonce_field( 'lpm_contact_form', 'lpm_nonce' ); ?>
      <input type="text" name="lpm_hp" style="position:absolute;left:-9999px;opacity:0;" tabindex="-1" autocomplete="off" aria-hidden="true">

      <?php if ( 'success' === $status ) : ?>
        <div class="lpm-alert lpm-alert--success" role="alert">✅ Request received! We'll reply within 24 hours.</div>
      <?php elseif ( 'error' === $status ) : ?>
        <div class="lpm-alert lpm-alert--error" role="alert">⚠️ Please fill all fields with a valid email.</div>
      <?php endif; ?>

      <div class="lpm-form__row">
        <div class="lpm-form__field">
          <label for="lpm_name">Your Name</label>
          <input type="text" id="lpm_name" name="lpm_name" placeholder="Arjun Singh" required autocomplete="name">
        </div>
        <div class="lpm-form__field">
          <label for="lpm_email">Email Address</label>
          <input type="email" id="lpm_email" name="lpm_email" placeholder="you@company.com" required autocomplete="email">
        </div>
      </div>

      <div class="lpm-form__field">
        <label for="lpm_message">Project Details</label>
        <textarea id="lpm_message" name="lpm_message" placeholder="Describe your project — type, size, location, timeline..." required rows="5"></textarea>
      </div>

      <button type="submit" class="lpm-btn lpm-btn--primary lpm-btn--lg">Send Request →</button>
    </form>
  </div>
</section>

<!-- ═══ FOOTER ═══ -->
<footer class="lpm-footer" role="contentinfo">
  <div class="lpm-wrap lpm-footer__inner">
    <span class="lpm-footer__brand">
      <?php if ( ! empty( $data['logo_image'] ) ) : ?>
        <img src="<?php echo esc_url( $data['logo_image'] ); ?>" alt="" style="max-height:28px;vertical-align:middle;margin-right:6px;">
      <?php else : ?>
        🏗️
      <?php endif; ?>
      <?php echo esc_html( $data['logo_text'] ?: $data['site_name'] ); ?>
    </span>
    <nav class="lpm-footer__links" aria-label="Footer navigation">
      <?php foreach ( $data['nav'] as $link ) : ?>
        <a href="<?php echo esc_attr( $link['href'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a>
      <?php endforeach; ?>
    </nav>
    <p class="lpm-footer__copy">&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( $data['site_name'] ); ?>. All rights reserved.</p>
  </div>
</footer>

<?php if ( 'success' === $status ) : ?>
<div class="lpm-popup-overlay" id="lpmSuccessPopup" role="dialog" aria-modal="true" aria-label="Request received">
  <div class="lpm-popup">
    <div class="lpm-popup__icon">✅</div>
    <h3 class="lpm-popup__title">Request Received!</h3>
    <p class="lpm-popup__msg">We'll reply within 24 hours.</p>
    <button class="lpm-popup__close" onclick="document.getElementById('lpmSuccessPopup').remove()">OK</button>
  </div>
</div>
<script>
(function(){
  var url = new URL(window.location.href);
  url.searchParams.delete('lpm_status');
  history.replaceState(null, '', url.toString());
})();
</script>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
