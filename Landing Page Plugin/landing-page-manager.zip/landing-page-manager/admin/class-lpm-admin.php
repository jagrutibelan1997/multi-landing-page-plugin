<?php
/**
 * Landing Page Manager — Admin Dashboard
 * Sidebar menu with dropdown submenus + editable content forms.
 * Author: Jagruti Belan
 */
defined( 'ABSPATH' ) || exit;

class LPM_Admin {

    // ── Bootstrap ─────────────────────────────────────────────────────────────

    public static function init(): void {
        add_action( 'admin_menu',            [ __CLASS__, 'register_menus' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
        add_action( 'admin_post_lpm_save_settings',     [ __CLASS__, 'save_settings' ] );
        add_action( 'admin_post_lpm_save_yoga',         [ __CLASS__, 'save_yoga' ] );
        add_action( 'admin_post_lpm_save_construction', [ __CLASS__, 'save_construction' ] );
        add_action( 'admin_post_lpm_save_hospital',     [ __CLASS__, 'save_hospital' ] );
        add_action( 'admin_post_lpm_save_jewellery',    [ __CLASS__, 'save_jewellery' ] );
        add_action( 'admin_post_lpm_delete_lead',       [ __CLASS__, 'delete_lead' ] );
        add_action( 'admin_post_lpm_mark_lead_read',    [ __CLASS__, 'mark_lead_read' ] );
        add_action( 'admin_post_lpm_clear_read_leads',  [ __CLASS__, 'clear_read_leads' ] );
        add_action( 'admin_post_lpm_clear_all_leads',   [ __CLASS__, 'clear_all_leads' ] );
        add_action( 'admin_notices',         [ __CLASS__, 'admin_notice' ] );
        add_action( 'admin_enqueue_scripts',  [ __CLASS__, 'inactive_template_styles' ] );
    }

    // ── Admin Menu ────────────────────────────────────────────────────────────

    /**
     * Dim inactive template menu items in the sidebar.
     */
    public static function inactive_template_styles(): void {
        $settings       = get_option( 'lpm_settings', [] );
        $active_variant = sanitize_key( $settings['site_type'] ?? 'yoga' );
        $all_variants   = [ 'yoga', 'construction', 'hospital', 'jewellery' ];
        $css = '';
        foreach ( $all_variants as $v ) {
            if ( $v === $active_variant ) { continue; }
            $slug = 'lpm-' . sanitize_key( $v );
            $css .= '#adminmenu a[href*="' . $slug . '"] { opacity: 0.3; color: rgba(255,255,255,0.3) !important; pointer-events: none; cursor: default; }' . "\n";
        }
        if ( $css ) {
            // Inline-only style handle — no src file needed.
            wp_register_style( 'lpm-sidebar-dim', false, [], LPM_VERSION ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
            wp_enqueue_style( 'lpm-sidebar-dim' );
            wp_add_inline_style( 'lpm-sidebar-dim', $css );
        }
    }

    public static function register_menus(): void {
        add_menu_page(
            __( 'Landing Page Manager', 'landing-page-manager' ),
            __( 'Landing Page', 'landing-page-manager' ),
            'manage_options',
            'lpm-dashboard',
            [ __CLASS__, 'page_dashboard' ],
            'dashicons-layout',
            30
        );

        add_submenu_page(
            'lpm-dashboard',
            __( 'Dashboard', 'landing-page-manager' ),
            __( 'Dashboard', 'landing-page-manager' ),
            'manage_options',
            'lpm-dashboard',
            [ __CLASS__, 'page_dashboard' ]
        );

        add_submenu_page(
            'lpm-dashboard',
            __( 'Settings', 'landing-page-manager' ),
            __( 'Settings', 'landing-page-manager' ),
            'manage_options',
            'lpm-settings',
            [ __CLASS__, 'page_settings' ]
        );

        // Leads badge count — scoped to the active variant.
        global $wpdb;
        $lpm_settings_reg   = get_option( 'lpm_settings', [] );
        $active_variant_reg = sanitize_key( $lpm_settings_reg['site_type'] ?? 'yoga' );
        $new_leads = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}lpm_leads WHERE status = 'new' AND variant = %s", $active_variant_reg ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $leads_label = __( '📧 Leads', 'landing-page-manager' );
        if ( $new_leads > 0 ) {
            $leads_label .= ' <span class="awaiting-mod count-' . $new_leads . '"><span class="pending-count">' . $new_leads . '</span></span>';
        }

        add_submenu_page(
            'lpm-dashboard',
            __( 'Leads', 'landing-page-manager' ),
            $leads_label,
            'manage_options',
            'lpm-leads',
            [ __CLASS__, 'page_leads' ]
        );

        add_submenu_page(
            'lpm-dashboard',
            __( 'Yoga Content', 'landing-page-manager' ),
            __( '🌿 Yoga Content', 'landing-page-manager' ),
            'manage_options',
            'lpm-yoga',
            [ __CLASS__, 'page_yoga' ]
        );

        add_submenu_page(
            'lpm-dashboard',
            __( 'Construction Content', 'landing-page-manager' ),
            __( '🏗️ Construction', 'landing-page-manager' ),
            'manage_options',
            'lpm-construction',
            [ __CLASS__, 'page_construction' ]
        );

        add_submenu_page(
            'lpm-dashboard',
            __( 'Hospital Content', 'landing-page-manager' ),
            __( '🏥 Hospital', 'landing-page-manager' ),
            'manage_options',
            'lpm-hospital',
            [ __CLASS__, 'page_hospital' ]
        );

        add_submenu_page(
            'lpm-dashboard',
            __( 'Jewellery Content', 'landing-page-manager' ),
            __( '💎 Jewellery', 'landing-page-manager' ),
            'manage_options',
            'lpm-jewellery',
            [ __CLASS__, 'page_jewellery' ]
        );
    }

    // ── Enqueue Admin CSS ─────────────────────────────────────────────────────

    public static function enqueue_assets( string $hook ): void {
        $lpm_pages = [
            'toplevel_page_lpm-dashboard',
            'landing-page_page_lpm-settings',
            'landing-page_page_lpm-leads',
            'landing-page_page_lpm-yoga',
            'landing-page_page_lpm-construction',
            'landing-page_page_lpm-hospital',
            'landing-page_page_lpm-jewellery',
        ];
        if ( ! in_array( $hook, $lpm_pages, true ) ) {
            return;
        }
        wp_enqueue_style(
            'lpm-admin',
            LPM_URL . 'assets/css/admin.css',
            [],
            LPM_VERSION
        );
        // Load WP media uploader for logo image picker (not needed on leads page).
        if ( 'landing-page_page_lpm-leads' !== $hook ) {
            wp_enqueue_media();
        }
    }

    // ── Admin Notice (success/error after save) ────────────────────────────────

    public static function admin_notice(): void {
        $screen = get_current_screen();
        if ( ! $screen || strpos( $screen->id, 'lpm-' ) === false ) {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification
        $status = isset( $_GET['lpm_saved'] ) ? sanitize_key( $_GET['lpm_saved'] ) : '';
        if ( 'ok' === $status ) {
            echo '<div class="notice notice-success is-dismissible"><p><strong>Landing Page Manager:</strong> Settings saved successfully!</p></div>';
        } elseif ( 'fail' === $status ) {
            echo '<div class="notice notice-error is-dismissible"><p><strong>Landing Page Manager:</strong> Save failed. Please try again.</p></div>';
        }
    }

    // ── Page: Dashboard ────────────────────────────────────────────────────────

    public static function page_dashboard(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $settings  = get_option( 'lpm_settings', [] );
        $site_type = $settings['site_type'] ?? 'yoga';
        $active    = (bool) get_option( 'lpm_active', 0 );
        ?>
        <div class="wrap lpm-wrap-admin">
            <div class="lpm-admin-header">
                <span class="lpm-admin-logo">🏠</span>
                <div>
                    <h1 class="lpm-admin-title">Landing Page Manager</h1>
                    <p class="lpm-admin-subtitle">Manage your high-converting landing pages from one place.</p>
                </div>
            </div>

            <div class="lpm-cards-row">

                <div class="lpm-info-card lpm-info-card--<?php echo esc_attr( $active ? 'active' : 'inactive' ); ?>">
                    <span class="lpm-info-card__icon"><?php echo esc_html( $active ? '✅' : '⭕' ); ?></span>
                    <div>
                        <strong><?php echo esc_html( $active ? 'Plugin is Active' : 'Plugin is Inactive' ); ?></strong>
                        <p>Landing page is <?php echo esc_html( $active ? 'overriding your homepage.' : 'not displayed.' ); ?></p>
                    </div>
                </div>

                <div class="lpm-info-card">
                    <?php
                    $variant_icons = [ 'yoga' => '🌿', 'construction' => '🏗️', 'hospital' => '🏥', 'jewellery' => '💎' ];
                    $variant_names = [ 'yoga' => 'Yoga', 'construction' => 'Construction', 'hospital' => 'Hospital', 'jewellery' => 'Jewellery' ];
                    ?>
                    <span class="lpm-info-card__icon"><?php echo esc_html( $variant_icons[ $site_type ] ?? '🏠' ); ?></span>
                    <div>
                        <strong>Active Variant</strong>
                        <p><?php echo esc_html( ( $variant_names[ $site_type ] ?? ucfirst( $site_type ) ) . ' Landing Page' ); ?></p>
                    </div>
                </div>

                <div class="lpm-info-card">
                    <span class="lpm-info-card__icon">🔗</span>
                    <div>
                        <strong>Preview</strong>
                        <p><a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank">View Homepage ↗</a></p>
                    </div>
                </div>

            </div>

            <div class="lpm-quick-actions">
                <h2>Quick Actions</h2>
                <div class="lpm-quick-links">
                    <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=lpm-settings' ) ); ?>">⚙️ Settings</a>
                    <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=lpm-yoga' ) ); ?>">🌿 Yoga Content</a>
                    <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=lpm-construction' ) ); ?>">🏗️ Construction Content</a>
                    <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=lpm-hospital' ) ); ?>">🏥 Hospital Content</a>
                    <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=lpm-jewellery' ) ); ?>">💎 Jewellery Content</a>
                    <a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank">🌐 View Site</a>
                </div>
            </div>
        </div>
        <?php
    }

    // ── Page: Settings ─────────────────────────────────────────────────────────

    public static function page_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $settings  = get_option( 'lpm_settings', [] );
        $site_type = $settings['site_type'] ?? 'yoga';
        ?>
        <div class="wrap lpm-wrap-admin">
            <div class="lpm-admin-header">
                <span class="lpm-admin-logo">⚙️</span>
                <div>
                    <h1 class="lpm-admin-title">Settings</h1>
                    <p class="lpm-admin-subtitle">Choose which landing page to display and configure general options.</p>
                </div>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="lpm_save_settings">
                <?php wp_nonce_field( 'lpm_save_settings', 'lpm_nonce' ); ?>

                <div class="lpm-form-card">
                    <h2 class="lpm-form-card__title">Active Landing Page</h2>
                    <p class="lpm-form-card__desc">Select which landing page variant to display as the homepage.</p>

                    <div class="lpm-variant-chooser lpm-variant-chooser--4">
                        <label class="lpm-variant-option <?php echo 'yoga' === $site_type ? 'is-selected' : ''; ?>">
                            <input type="radio" name="site_type" value="yoga" <?php checked( $site_type, 'yoga' ); ?>>
                            <span class="lpm-variant-option__icon">🌿</span>
                            <span class="lpm-variant-option__label">Yoga</span>
                            <span class="lpm-variant-option__desc">Serene, warm earth-tone landing page for yoga studios.</span>
                        </label>
                        <label class="lpm-variant-option <?php echo 'construction' === $site_type ? 'is-selected' : ''; ?>">
                            <input type="radio" name="site_type" value="construction" <?php checked( $site_type, 'construction' ); ?>>
                            <span class="lpm-variant-option__icon">🏗️</span>
                            <span class="lpm-variant-option__label">Construction</span>
                            <span class="lpm-variant-option__desc">Bold, industrial landing page for construction businesses.</span>
                        </label>
                        <label class="lpm-variant-option <?php echo 'hospital' === $site_type ? 'is-selected' : ''; ?>">
                            <input type="radio" name="site_type" value="hospital" <?php checked( $site_type, 'hospital' ); ?>>
                            <span class="lpm-variant-option__icon">🏥</span>
                            <span class="lpm-variant-option__label">Hospital</span>
                            <span class="lpm-variant-option__desc">Professional cobalt-blue landing page for hospitals & clinics.</span>
                        </label>
                        <label class="lpm-variant-option <?php echo 'jewellery' === $site_type ? 'is-selected' : ''; ?>">
                            <input type="radio" name="site_type" value="jewellery" <?php checked( $site_type, 'jewellery' ); ?>>
                            <span class="lpm-variant-option__icon">💎</span>
                            <span class="lpm-variant-option__label">Jewellery</span>
                            <span class="lpm-variant-option__desc">Luxurious gold & rose landing page for jewellery boutiques.</span>
                        </label>
                    </div>
                </div>

                <div class="lpm-form-actions">
                    <?php submit_button( 'Save Settings', 'primary', 'submit', false ); ?>
                </div>
            </form>
        </div>
        <script>
        (function () {
            var opts = document.querySelectorAll('.lpm-variant-option');
            opts.forEach(function (el) {
                el.addEventListener('click', function () {
                    opts.forEach(function (o) { o.classList.remove('is-selected'); });
                    el.classList.add('is-selected');
                });
            });
        }());
        </script>
        <?php
    }

    // ── Page: Leads ────────────────────────────────────────────────────────────

    public static function page_leads(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'lpm_leads';

        // Active variant.
        $settings       = get_option( 'lpm_settings', [] );
        $active_variant = sanitize_key( $settings['site_type'] ?? 'yoga' );

        $variant_icons = [ 'yoga' => '🌿', 'construction' => '🏗️', 'hospital' => '🏥', 'jewellery' => '💎' ];
        $variant_icon  = $variant_icons[ $active_variant ] ?? '🌐';

        // ── Filter ─────────────────────────────────────────────────────────────
        // phpcs:ignore WordPress.Security.NonceVerification
        $filter  = isset( $_GET['lpm_filter'] ) ? sanitize_key( $_GET['lpm_filter'] ) : 'all';
        // phpcs:ignore WordPress.Security.NonceVerification
        $paged   = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
        $per_page = 20;
        $offset   = ( $paged - 1 ) * $per_page;

        // All queries scoped to the active variant.
        $where_variant = $wpdb->prepare( "WHERE variant = %s", $active_variant );
        if ( 'new' === $filter )  { $where_variant = $wpdb->prepare( "WHERE variant = %s AND status = 'new'",  $active_variant ); }
        if ( 'read' === $filter ) { $where_variant = $wpdb->prepare( "WHERE variant = %s AND status = 'read'", $active_variant ); }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} {$where_variant}" );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
        $leads = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} {$where_variant} ORDER BY created_at DESC LIMIT %d OFFSET %d", $per_page, $offset ) );

        // Tab counts scoped to active variant.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
        $count_all  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} " . $wpdb->prepare( "WHERE variant = %s", $active_variant ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
        $count_new  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} " . $wpdb->prepare( "WHERE variant = %s AND status = 'new'", $active_variant ) );
        $count_read = $count_all - $count_new;

        $total_pages = (int) ceil( $total / $per_page );
        $base_url    = admin_url( 'admin.php?page=lpm-leads' );
        $filter_url  = add_query_arg( 'lpm_filter', $filter, $base_url );
        ?>
        <div class="wrap lpm-wrap-admin">
            <div class="lpm-admin-header">
                <span class="lpm-admin-logo">📧</span>
                <div>
                    <h1 class="lpm-admin-title">Leads</h1>
                    <p class="lpm-admin-subtitle"><?php echo esc_html( $variant_icon . ' ' . ucfirst( $active_variant ) ); ?> — contact form submissions from the active template.</p>
                </div>
            </div>

            <?php if ( $count_new > 0 ) : ?>
                <div class="notice notice-info lpm-leads-notice">
                    <p>📬 You have <strong><?php echo esc_html( $count_new ); ?> new lead<?php echo $count_new > 1 ? 's' : ''; ?></strong> awaiting review.</p>
                </div>
            <?php endif; ?>

            <!-- Filter tabs -->
            <div class="lpm-leads-tabs">
                <a href="<?php echo esc_url( $base_url ); ?>" class="lpm-leads-tab <?php echo 'all' === $filter ? 'is-active' : ''; ?>">
                    All <span class="lpm-leads-tab__count"><?php echo esc_html( $count_all ); ?></span>
                </a>
                <a href="<?php echo esc_url( add_query_arg( 'lpm_filter', 'new', $base_url ) ); ?>" class="lpm-leads-tab <?php echo 'new' === $filter ? 'is-active' : ''; ?>">
                    🔵 New <span class="lpm-leads-tab__count"><?php echo esc_html( $count_new ); ?></span>
                </a>
                <a href="<?php echo esc_url( add_query_arg( 'lpm_filter', 'read', $base_url ) ); ?>" class="lpm-leads-tab <?php echo 'read' === $filter ? 'is-active' : ''; ?>">
                    ✅ Read <span class="lpm-leads-tab__count"><?php echo esc_html( $count_read ); ?></span>
                </a>

                <div class="lpm-leads-tabs__actions">
                    <?php if ( $count_read > 0 ) : ?>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
                            <input type="hidden" name="action" value="lpm_clear_read_leads">
                            <input type="hidden" name="lpm_filter" value="<?php echo esc_attr( $filter ); ?>">
                            <?php wp_nonce_field( 'lpm_clear_read_leads', 'lpm_nonce' ); ?>
                            <button type="submit" class="button" onclick="return confirm('Delete all read leads? This cannot be undone.')">🗑️ Clear Read</button>
                        </form>
                    <?php endif; ?>
                    <?php if ( $count_all > 0 ) : ?>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
                            <input type="hidden" name="action" value="lpm_clear_all_leads">
                            <input type="hidden" name="lpm_filter" value="<?php echo esc_attr( $filter ); ?>">
                            <?php wp_nonce_field( 'lpm_clear_all_leads', 'lpm_nonce' ); ?>
                            <button type="submit" class="button button-link-delete" onclick="return confirm('Delete ALL leads? This cannot be undone.')">🗑️ Clear All</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ( empty( $leads ) ) : ?>
                <div class="lpm-leads-empty">
                    <span>📭</span>
                    <p><?php echo 'all' === $filter ? 'No leads yet. They will appear here when visitors submit the contact form.' : 'No ' . esc_html( $filter ) . ' leads.'; ?></p>
                </div>
            <?php else : ?>

                <table class="lpm-leads-table widefat striped">
                    <thead>
                        <tr>
                            <th class="lpm-leads-col--status">Status</th>
                            <th class="lpm-leads-col--variant">Variant</th>
                            <th class="lpm-leads-col--name">Name</th>
                            <th class="lpm-leads-col--email">Email</th>
                            <th class="lpm-leads-col--phone">Phone</th>
                            <th class="lpm-leads-col--message">Message</th>
                            <th class="lpm-leads-col--date">Date</th>
                            <th class="lpm-leads-col--actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $leads as $lead ) : ?>
                        <tr class="lpm-lead-row lpm-lead-row--<?php echo esc_attr( $lead->status ); ?>">
                            <td>
                                <?php if ( 'new' === $lead->status ) : ?>
                                    <span class="lpm-lead-badge lpm-lead-badge--new">🔵 New</span>
                                <?php else : ?>
                                    <span class="lpm-lead-badge lpm-lead-badge--read">✅ Read</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="lpm-lead-variant">
                                    <?php echo esc_html( ( $variant_icons[ $lead->variant ] ?? '🌐' ) . ' ' . ucfirst( $lead->variant ) ); ?>
                                </span>
                            </td>
                            <td><strong><?php echo esc_html( $lead->name ); ?></strong></td>
                            <td><a href="mailto:<?php echo esc_attr( $lead->email ); ?>"><?php echo esc_html( $lead->email ); ?></a></td>
                            <td><?php echo esc_html( $lead->phone ?: '—' ); ?></td>
                            <td>
                                <span class="lpm-lead-message" title="<?php echo esc_attr( $lead->message ); ?>">
                                    <?php echo esc_html( mb_strimwidth( $lead->message, 0, 80, '…' ) ); ?>
                                </span>
                            </td>
                            <td>
                                <span class="lpm-lead-date" title="<?php echo esc_attr( $lead->created_at ); ?>">
                                    <?php echo esc_html( date_i18n( 'M j, Y', strtotime( $lead->created_at ) ) ); ?>
                                    <br><small><?php echo esc_html( date_i18n( 'g:i a', strtotime( $lead->created_at ) ) ); ?></small>
                                </span>
                            </td>
                            <td class="lpm-lead-actions">
                                <?php if ( 'new' === $lead->status ) : ?>
                                    <a class="button button-small"
                                       href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'lpm_mark_lead_read', 'id' => $lead->id, 'lpm_filter' => $filter ], admin_url( 'admin-post.php' ) ), 'lpm_mark_lead_read_' . $lead->id ) ); ?>">
                                        ✅ Mark Read
                                    </a>
                                <?php endif; ?>
                                <a class="button button-small lpm-btn-delete"
                                   href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'lpm_delete_lead', 'id' => $lead->id, 'lpm_filter' => $filter ], admin_url( 'admin-post.php' ) ), 'lpm_delete_lead_' . $lead->id ) ); ?>"
                                   onclick="return confirm('Delete this lead?')">
                                    🗑️ Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php if ( $total_pages > 1 ) : ?>
                    <div class="lpm-leads-pagination">
                        <span class="lpm-leads-pagination__info">
                            Showing <?php echo esc_html( $offset + 1 ); ?>–<?php echo esc_html( min( $offset + $per_page, $total ) ); ?> of <?php echo esc_html( $total ); ?>
                        </span>
                        <?php if ( $paged > 1 ) : ?>
                            <a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $paged - 1, $filter_url ) ); ?>">← Previous</a>
                        <?php endif; ?>
                        <?php if ( $paged < $total_pages ) : ?>
                            <a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $paged + 1, $filter_url ) ); ?>">Next →</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            <?php endif; ?>
        </div>
        <?php
    }

    // ── Lead Action Handlers ───────────────────────────────────────────────────

    public static function delete_lead(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'landing-page-manager' ) );
        }
        $id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
        if ( ! $id || ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'lpm_delete_lead_' . $id ) ) {
            wp_die( esc_html__( 'Security check failed.', 'landing-page-manager' ) );
        }
        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'lpm_leads', [ 'id' => $id ], [ '%d' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $filter = sanitize_key( $_GET['lpm_filter'] ?? 'all' );
        wp_safe_redirect( add_query_arg( [ 'page' => 'lpm-leads', 'lpm_filter' => $filter, 'lpm_saved' => 'ok' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function mark_lead_read(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'landing-page-manager' ) );
        }
        $id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
        if ( ! $id || ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'lpm_mark_lead_read_' . $id ) ) {
            wp_die( esc_html__( 'Security check failed.', 'landing-page-manager' ) );
        }
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'lpm_leads', [ 'status' => 'read' ], [ 'id' => $id ], [ '%s' ], [ '%d' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $filter = sanitize_key( $_GET['lpm_filter'] ?? 'all' );
        wp_safe_redirect( add_query_arg( [ 'page' => 'lpm-leads', 'lpm_filter' => $filter, 'lpm_saved' => 'ok' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function clear_read_leads(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'landing-page-manager' ) );
        }
        $nonce = isset( $_POST['lpm_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['lpm_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'lpm_clear_read_leads' ) ) {
            wp_die( esc_html__( 'Security check failed.', 'landing-page-manager' ) );
        }
        global $wpdb;
        $settings       = get_option( 'lpm_settings', [] );
        $active_variant = sanitize_key( $settings['site_type'] ?? 'yoga' );
        $wpdb->delete( $wpdb->prefix . 'lpm_leads', [ 'status' => 'read', 'variant' => $active_variant ], [ '%s', '%s' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $filter = sanitize_key( $_POST['lpm_filter'] ?? 'all' );
        wp_safe_redirect( add_query_arg( [ 'page' => 'lpm-leads', 'lpm_filter' => $filter, 'lpm_saved' => 'ok' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function clear_all_leads(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'landing-page-manager' ) );
        }
        $nonce = isset( $_POST['lpm_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['lpm_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'lpm_clear_all_leads' ) ) {
            wp_die( esc_html__( 'Security check failed.', 'landing-page-manager' ) );
        }
        global $wpdb;
        $settings       = get_option( 'lpm_settings', [] );
        $active_variant = sanitize_key( $settings['site_type'] ?? 'yoga' );
        $wpdb->delete( $wpdb->prefix . 'lpm_leads', [ 'variant' => $active_variant ], [ '%s' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        wp_safe_redirect( add_query_arg( [ 'page' => 'lpm-leads', 'lpm_saved' => 'ok' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    // ── Page: Yoga Content ─────────────────────────────────────────────────────

    public static function page_yoga(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $defaults = lpm_get_defaults( 'yoga' );
        $saved    = get_option( 'lpm_content_yoga', [] );
        $d        = array_replace_recursive( $defaults, $saved );
        ?>
        <div class="wrap lpm-wrap-admin">
            <div class="lpm-admin-header">
                <span class="lpm-admin-logo">🌿</span>
                <div>
                    <h1 class="lpm-admin-title">Yoga Landing Page Content</h1>
                    <p class="lpm-admin-subtitle">Edit all text, links and images for the yoga landing page.</p>
                </div>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="lpm_save_yoga">
                <?php wp_nonce_field( 'lpm_save_yoga', 'lpm_nonce' ); ?>

                <?php
                self::render_general_card( $d );
                self::render_hero_card( $d );
                self::render_about_card( $d );
                self::render_contact_card( $d );
                ?>

                <div class="lpm-form-actions">
                    <?php submit_button( 'Save Yoga Content', 'primary', 'submit', false ); ?>
                    <a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank">Preview →</a>
                </div>
            </form>
        </div>
        <?php
    }

    // ── Page: Construction Content ─────────────────────────────────────────────

    public static function page_construction(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $defaults = lpm_get_defaults( 'construction' );
        $saved    = get_option( 'lpm_content_construction', [] );
        $d        = array_replace_recursive( $defaults, $saved );
        ?>
        <div class="wrap lpm-wrap-admin">
            <div class="lpm-admin-header">
                <span class="lpm-admin-logo">🏗️</span>
                <div>
                    <h1 class="lpm-admin-title">Construction Landing Page Content</h1>
                    <p class="lpm-admin-subtitle">Edit all text, links and images for the construction landing page.</p>
                </div>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="lpm_save_construction">
                <?php wp_nonce_field( 'lpm_save_construction', 'lpm_nonce' ); ?>

                <?php
                self::render_general_card( $d );
                self::render_hero_card( $d );
                self::render_about_card( $d );
                self::render_contact_card( $d );
                ?>

                <div class="lpm-form-actions">
                    <?php submit_button( 'Save Construction Content', 'primary', 'submit', false ); ?>
                    <a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank">Preview →</a>
                </div>
            </form>
        </div>
        <?php
    }

    // ── Form Cards ─────────────────────────────────────────────────────────────

    private static function render_general_card( array $d ): void {
        ?>
        <div class="lpm-form-card">
            <h2 class="lpm-form-card__title">🏷️ General</h2>
            <div class="lpm-form-grid lpm-form-grid--2">
                <div class="lpm-field">
                    <label for="site_name">Site Name <span style="font-weight:400;color:#646970;">(optional)</span></label>
                    <input type="text" id="site_name" name="site_name" value="<?php echo esc_attr( $d['site_name'] ?? '' ); ?>" class="regular-text">
                </div>
                <div class="lpm-field">
                    <label for="tagline">Tagline</label>
                    <input type="text" id="tagline" name="tagline" value="<?php echo esc_attr( $d['tagline'] ?? '' ); ?>" class="regular-text">
                </div>
            </div>
        </div>

        <div class="lpm-form-card">
            <h2 class="lpm-form-card__title">🖼️ Logo</h2>
            <p class="lpm-form-card__desc">Upload a logo image <em>or</em> leave it empty to display the site name as text. Both can be shown together.</p>
            <div class="lpm-form-grid lpm-form-grid--2">

                <div class="lpm-field lpm-field--full">
                    <label for="logo_image">Logo Image URL <span class="lpm-hint">(paste any image URL or use WordPress Media Library)</span></label>
                    <p class="lpm-size-badge">📐 Recommended: <strong>174 × 53 px</strong> — transparent PNG or SVG works best</p>
                    <div class="lpm-logo-uploader">
                        <input type="url" id="logo_image" name="logo_image" value="<?php echo esc_attr( $d['logo_image'] ?? '' ); ?>" class="large-text lpm-logo-url-input lpm-img-url" data-preview="logo_preview" placeholder="https://your-site.com/logo.png">
                        <button type="button" class="button lpm-media-pick" data-target="logo_image" data-preview="logo_preview">📁 Choose Image</button>
                    </div>
                    <?php if ( ! empty( $d['logo_image'] ) ) : ?>
                        <div class="lpm-img-preview lpm-logo-preview" id="logo_preview">
                            <img src="<?php echo esc_url( $d['logo_image'] ); ?>" alt="Logo preview" loading="lazy" style="max-height:80px;width:auto;object-fit:contain;">
                        </div>
                    <?php else : ?>
                        <div class="lpm-img-preview lpm-logo-preview" id="logo_preview" style="display:none;"></div>
                    <?php endif; ?>
                </div>

                <div class="lpm-field">
                    <label for="logo_text">Logo Display Name <span class="lpm-hint">(shown in nav next to logo image)</span></label>
                    <input type="text" id="logo_text" name="logo_text" value="<?php echo esc_attr( $d['logo_text'] ?? '' ); ?>" class="regular-text" placeholder="Leave empty to use Site Name">
                </div>

                <div class="lpm-field lpm-field--full">
                    <p class="lpm-logo-preview-row">
                        <strong>Nav Preview:</strong>&nbsp;
                        <?php if ( ! empty( $d['logo_image'] ) ) : ?>
                            <img src="<?php echo esc_url( $d['logo_image'] ); ?>" alt="" style="max-height:36px;vertical-align:middle;margin-right:6px;">
                        <?php endif; ?>
                        <span style="font-weight:700;"><?php echo esc_html( $d['logo_text'] ?: $d['site_name'] ?? '' ); ?></span>
                    </p>
                </div>

            </div>
        </div>
        <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Live preview for ALL image URL inputs that have data-preview set.
            document.querySelectorAll('.lpm-img-url[data-preview]').forEach(function (input) {
                input.addEventListener('input', function () {
                    var previewWrap = document.getElementById(input.dataset.preview);
                    if ( ! previewWrap ) { return; }
                    var src = input.value.trim();
                    if ( src ) {
                        previewWrap.style.display = '';
                        previewWrap.innerHTML = '<img src="' + src + '" alt="Preview" style="max-height:120px;width:auto;max-width:100%;object-fit:contain;" loading="lazy">';
                    } else {
                        previewWrap.style.display = 'none';
                        previewWrap.innerHTML = '';
                    }
                });
            });
            // WP Media Library picker for ALL .lpm-media-pick buttons.
            document.querySelectorAll('.lpm-media-pick').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    if ( typeof wp === 'undefined' || ! wp.media ) { return; }
                    var targetId = btn.dataset.target;
                    var frame = wp.media({ title: 'Select Image', button: { text: 'Use this image' }, multiple: false });
                    frame.on('select', function () {
                        var attachment = frame.state().get('selection').first().toJSON();
                        var inp = document.getElementById(targetId);
                        if ( inp ) {
                            inp.value = attachment.url;
                            inp.dispatchEvent(new Event('input'));
                        }
                    });
                    frame.open();
                });
            });
        });
        </script>
        <?php
    }

    private static function render_hero_card( array $d ): void {
        $hero = $d['hero'] ?? [];
        ?>
        <div class="lpm-form-card">
            <h2 class="lpm-form-card__title">🦸 Hero Section</h2>
            <div class="lpm-form-grid lpm-form-grid--2">

                <div class="lpm-field">
                    <label for="hero_eyebrow">Eyebrow Text <span class="lpm-hint">(small badge above headline)</span></label>
                    <input type="text" id="hero_eyebrow" name="hero[eyebrow]" value="<?php echo esc_attr( $hero['eyebrow'] ?? '' ); ?>" class="regular-text">
                </div>

                <div class="lpm-field lpm-field--full">
                    <label for="hero_headline">Main Headline</label>
                    <input type="text" id="hero_headline" name="hero[headline]" value="<?php echo esc_attr( $hero['headline'] ?? '' ); ?>" class="large-text" required>
                </div>

                <div class="lpm-field lpm-field--full">
                    <label for="hero_subheading">Subheading</label>
                    <textarea id="hero_subheading" name="hero[subheading]" rows="3" class="large-text"><?php echo esc_textarea( $hero['subheading'] ?? '' ); ?></textarea>
                </div>

                <div class="lpm-field">
                    <label for="hero_cta_text">Primary CTA Text</label>
                    <input type="text" id="hero_cta_text" name="hero[cta_text]" value="<?php echo esc_attr( $hero['cta_text'] ?? '' ); ?>" class="regular-text">
                </div>

                <div class="lpm-field">
                    <label for="hero_cta_url">Primary CTA URL</label>
                    <input type="text" id="hero_cta_url" name="hero[cta_url]" value="<?php echo esc_attr( $hero['cta_url'] ?? '#contact' ); ?>" class="regular-text">
                </div>

                <div class="lpm-field">
                    <label for="hero_cta2_text">Secondary CTA Text</label>
                    <input type="text" id="hero_cta2_text" name="hero[cta2_text]" value="<?php echo esc_attr( $hero['cta2_text'] ?? '' ); ?>" class="regular-text">
                </div>

                <div class="lpm-field">
                    <label for="hero_cta2_url">Secondary CTA URL</label>
                    <input type="text" id="hero_cta2_url" name="hero[cta2_url]" value="<?php echo esc_attr( $hero['cta2_url'] ?? '#classes' ); ?>" class="regular-text">
                </div>

                <div class="lpm-field lpm-field--full">
                    <label for="hero_bg_image">Background Image URL</label>
                    <p class="lpm-size-badge">📐 Recommended: <strong>1920 × 1080 px</strong> — full-width landscape, high contrast</p>
                    <div class="lpm-logo-uploader">
                        <input type="url" id="hero_bg_image" name="hero[bg_image]" value="<?php echo esc_attr( $hero['bg_image'] ?? '' ); ?>" class="large-text lpm-img-url" data-preview="hero_bg_preview" placeholder="https://...">
                        <button type="button" class="button lpm-media-pick" data-target="hero_bg_image" data-preview="hero_bg_preview">📁 Choose Image</button>
                    </div>
                    <?php if ( ! empty( $hero['bg_image'] ) ) : ?>
                        <div class="lpm-img-preview" id="hero_bg_preview">
                            <img src="<?php echo esc_url( $hero['bg_image'] ); ?>" alt="Hero preview" loading="lazy">
                        </div>
                    <?php else : ?>
                        <div class="lpm-img-preview" id="hero_bg_preview" style="display:none;"></div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        <?php
    }

    private static function render_about_card( array $d ): void {
        $about = $d['about'] ?? [];
        ?>
        <div class="lpm-form-card">
            <h2 class="lpm-form-card__title">ℹ️ About Section</h2>
            <div class="lpm-form-grid lpm-form-grid--2">

                <div class="lpm-field lpm-field--full">
                    <label for="about_heading">Section Heading</label>
                    <input type="text" id="about_heading" name="about[heading]" value="<?php echo esc_attr( $about['heading'] ?? '' ); ?>" class="large-text">
                </div>

                <div class="lpm-field lpm-field--full">
                    <label for="about_lead">Lead Paragraph <span class="lpm-hint">(bold intro text)</span></label>
                    <textarea id="about_lead" name="about[lead]" rows="3" class="large-text"><?php echo esc_textarea( $about['lead'] ?? '' ); ?></textarea>
                </div>

                <div class="lpm-field lpm-field--full">
                    <label for="about_text">Body Text</label>
                    <textarea id="about_text" name="about[text]" rows="4" class="large-text"><?php echo esc_textarea( $about['text'] ?? '' ); ?></textarea>
                </div>

                <div class="lpm-field lpm-field--full">
                    <label for="about_image">About Image URL</label>
                    <p class="lpm-size-badge">📐 Recommended: <strong>560 × 420 px</strong> — portrait or landscape photo</p>
                    <div class="lpm-logo-uploader">
                        <input type="url" id="about_image" name="about[image]" value="<?php echo esc_attr( $about['image'] ?? '' ); ?>" class="large-text lpm-img-url" data-preview="about_img_preview" placeholder="https://...">
                        <button type="button" class="button lpm-media-pick" data-target="about_image" data-preview="about_img_preview">📁 Choose Image</button>
                    </div>
                    <?php if ( ! empty( $about['image'] ) ) : ?>
                        <div class="lpm-img-preview" id="about_img_preview">
                            <img src="<?php echo esc_url( $about['image'] ); ?>" alt="About preview" loading="lazy">
                        </div>
                    <?php else : ?>
                        <div class="lpm-img-preview" id="about_img_preview" style="display:none;"></div>
                    <?php endif; ?>
                </div>

                <?php
                $stats = $about['stats'] ?? [];
                foreach ( $stats as $i => $stat ) :
                ?>
                    <div class="lpm-field">
                        <label>Stat <?php echo esc_html( $i + 1 ); ?> — Value</label>
                        <input type="text" name="about[stats][<?php echo esc_attr( $i ); ?>][value]" value="<?php echo esc_attr( $stat['value'] ?? '' ); ?>" class="regular-text" placeholder="e.g. 5,000+">
                    </div>
                    <div class="lpm-field">
                        <label>Stat <?php echo esc_html( $i + 1 ); ?> — Label</label>
                        <input type="text" name="about[stats][<?php echo esc_attr( $i ); ?>][label]" value="<?php echo esc_attr( $stat['label'] ?? '' ); ?>" class="regular-text" placeholder="e.g. Students">
                    </div>
                <?php endforeach; ?>

            </div>
        </div>
        <?php
    }

    private static function render_contact_card( array $d ): void {
        $contact = $d['contact'] ?? [];
        ?>
        <div class="lpm-form-card">
            <h2 class="lpm-form-card__title">📞 Contact Section</h2>
            <div class="lpm-form-grid lpm-form-grid--2">

                <div class="lpm-field lpm-field--full">
                    <label for="contact_heading">Section Heading</label>
                    <input type="text" id="contact_heading" name="contact[heading]" value="<?php echo esc_attr( $contact['heading'] ?? '' ); ?>" class="regular-text">
                </div>

                <div class="lpm-field lpm-field--full">
                    <label for="contact_subtext">Section Subtext</label>
                    <input type="text" id="contact_subtext" name="contact[subtext]" value="<?php echo esc_attr( $contact['subtext'] ?? '' ); ?>" class="large-text">
                </div>

                <div class="lpm-field">
                    <label for="contact_address">Address</label>
                    <input type="text" id="contact_address" name="contact[address]" value="<?php echo esc_attr( $contact['address'] ?? '' ); ?>" class="regular-text">
                </div>

                <div class="lpm-field">
                    <label for="contact_email">Email</label>
                    <input type="email" id="contact_email" name="contact[email]" value="<?php echo esc_attr( $contact['email'] ?? '' ); ?>" class="regular-text">
                </div>

                <div class="lpm-field">
                    <label for="contact_phone">Phone</label>
                    <input type="text" id="contact_phone" name="contact[phone]" value="<?php echo esc_attr( $contact['phone'] ?? '' ); ?>" class="regular-text">
                </div>

                <div class="lpm-field">
                    <label for="contact_hours">Business Hours</label>
                    <input type="text" id="contact_hours" name="contact[hours]" value="<?php echo esc_attr( $contact['hours'] ?? '' ); ?>" class="regular-text" placeholder="Mon–Sat: 9 AM – 6 PM">
                </div>

            </div>
        </div>
        <?php
    }

    // ── Form Handlers ──────────────────────────────────────────────────────────

    public static function save_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'landing-page-manager' ) );
        }

        $nonce = isset( $_POST['lpm_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['lpm_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'lpm_save_settings' ) ) {
            wp_die( esc_html__( 'Security check failed.', 'landing-page-manager' ) );
        }

        $allowed   = [ 'yoga', 'construction', 'hospital', 'jewellery' ];
        $site_type = in_array( $_POST['site_type'] ?? '', $allowed, true ) ? $_POST['site_type'] : 'yoga';

        update_option( 'lpm_settings', [ 'site_type' => $site_type ] );

        // Clear the static cache so the new type is used.
        lpm_clear_config_cache();

        wp_safe_redirect( add_query_arg( [ 'page' => 'lpm-settings', 'lpm_saved' => 'ok' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function save_yoga(): void {
        self::save_content( 'yoga' );
    }

    public static function save_construction(): void {
        self::save_content( 'construction' );
    }

    public static function save_hospital(): void {
        self::save_content( 'hospital' );
    }

    public static function save_jewellery(): void {
        self::save_content( 'jewellery' );
    }

    private static function save_content( string $variant ): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'landing-page-manager' ) );
        }

        $nonce_action = "lpm_save_{$variant}";
        $nonce        = isset( $_POST['lpm_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['lpm_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, $nonce_action ) ) {
            wp_die( esc_html__( 'Security check failed.', 'landing-page-manager' ) );
        }

        $data = [];

        // General.
        $data['site_name']  = sanitize_text_field( wp_unslash( $_POST['site_name']  ?? '' ) );
        $data['tagline']    = sanitize_text_field( wp_unslash( $_POST['tagline']    ?? '' ) );
        $data['logo_image'] = esc_url_raw( wp_unslash( $_POST['logo_image'] ?? '' ) );
        $data['logo_text']  = sanitize_text_field( wp_unslash( $_POST['logo_text']  ?? '' ) );

        // Hero.
        $raw_hero = isset( $_POST['hero'] ) && is_array( $_POST['hero'] ) ? wp_unslash( $_POST['hero'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        $data['hero'] = [
            'eyebrow'    => sanitize_text_field( $raw_hero['eyebrow']    ?? '' ),
            'headline'   => sanitize_text_field( $raw_hero['headline']   ?? '' ),
            'subheading' => sanitize_textarea_field( $raw_hero['subheading'] ?? '' ),
            'cta_text'   => sanitize_text_field( $raw_hero['cta_text']   ?? '' ),
            'cta_url'    => sanitize_text_field( $raw_hero['cta_url']    ?? '#contact' ),
            'cta2_text'  => sanitize_text_field( $raw_hero['cta2_text']  ?? '' ),
            'cta2_url'   => sanitize_text_field( $raw_hero['cta2_url']   ?? '#classes' ),
            'bg_image'   => esc_url_raw( $raw_hero['bg_image'] ?? '' ),
        ];

        // About.
        $raw_about = isset( $_POST['about'] ) && is_array( $_POST['about'] ) ? wp_unslash( $_POST['about'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        $data['about'] = [
            'heading' => sanitize_text_field( $raw_about['heading'] ?? '' ),
            'lead'    => sanitize_textarea_field( $raw_about['lead'] ?? '' ),
            'text'    => sanitize_textarea_field( $raw_about['text'] ?? '' ),
            'image'   => esc_url_raw( $raw_about['image'] ?? '' ),
        ];

        // About stats.
        $raw_stats = isset( $raw_about['stats'] ) && is_array( $raw_about['stats'] ) ? $raw_about['stats'] : [];
        $stats = [];
        foreach ( $raw_stats as $stat ) {
            if ( ! empty( $stat['value'] ) || ! empty( $stat['label'] ) ) {
                $stats[] = [
                    'value' => sanitize_text_field( $stat['value'] ?? '' ),
                    'label' => sanitize_text_field( $stat['label'] ?? '' ),
                ];
            }
        }
        $data['about']['stats'] = $stats;

        // Contact.
        $raw_contact = isset( $_POST['contact'] ) && is_array( $_POST['contact'] ) ? wp_unslash( $_POST['contact'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        $data['contact'] = [
            'heading' => sanitize_text_field( $raw_contact['heading'] ?? '' ),
            'subtext' => sanitize_text_field( $raw_contact['subtext'] ?? '' ),
            'address' => sanitize_text_field( $raw_contact['address'] ?? '' ),
            'email'   => sanitize_email(      $raw_contact['email']   ?? '' ),
            'phone'   => sanitize_text_field( $raw_contact['phone']   ?? '' ),
            'hours'   => sanitize_text_field( $raw_contact['hours']   ?? '' ),
        ];

        update_option( "lpm_content_{$variant}", $data );
        lpm_clear_config_cache();

        wp_safe_redirect( add_query_arg( [ 'page' => "lpm-{$variant}", 'lpm_saved' => 'ok' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    // ── Page: Hospital Content ─────────────────────────────────────────────────

    public static function page_hospital(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $defaults = lpm_get_defaults( 'hospital' );
        $saved    = get_option( 'lpm_content_hospital', [] );
        $d        = array_replace_recursive( $defaults, $saved );
        ?>
        <div class="wrap lpm-wrap-admin">
            <div class="lpm-admin-header">
                <span class="lpm-admin-logo">🏥</span>
                <div>
                    <h1 class="lpm-admin-title">Hospital Landing Page Content</h1>
                    <p class="lpm-admin-subtitle">Edit all text, links and images for the hospital landing page.</p>
                </div>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="lpm_save_hospital">
                <?php wp_nonce_field( 'lpm_save_hospital', 'lpm_nonce' ); ?>

                <?php
                self::render_general_card( $d );
                self::render_hero_card( $d );
                self::render_about_card( $d );
                self::render_contact_card( $d );
                ?>

                <div class="lpm-form-actions">
                    <?php submit_button( 'Save Hospital Content', 'primary', 'submit', false ); ?>
                    <a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank">Preview →</a>
                </div>
            </form>
        </div>
        <?php
    }

    // ── Page: Jewellery Content ────────────────────────────────────────────────

    public static function page_jewellery(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $defaults = lpm_get_defaults( 'jewellery' );
        $saved    = get_option( 'lpm_content_jewellery', [] );
        $d        = array_replace_recursive( $defaults, $saved );
        ?>
        <div class="wrap lpm-wrap-admin">
            <div class="lpm-admin-header">
                <span class="lpm-admin-logo">💎</span>
                <div>
                    <h1 class="lpm-admin-title">Jewellery Landing Page Content</h1>
                    <p class="lpm-admin-subtitle">Edit all text, links and images for the jewellery landing page.</p>
                </div>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="lpm_save_jewellery">
                <?php wp_nonce_field( 'lpm_save_jewellery', 'lpm_nonce' ); ?>

                <?php
                self::render_general_card( $d );
                self::render_hero_card( $d );
                self::render_about_card( $d );
                self::render_contact_card( $d );
                ?>

                <div class="lpm-form-actions">
                    <?php submit_button( 'Save Jewellery Content', 'primary', 'submit', false ); ?>
                    <a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank">Preview →</a>
                </div>
            </form>
        </div>
        <?php
    }
}
