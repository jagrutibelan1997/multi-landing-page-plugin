<?php
/**
 * Plugin Name:       Landing Page Manager
 * Description:       Creates a high-converting landing page as your WordPress homepage. 4 variants: Yoga, Construction, Hospital, Jewellery. Manage all content, leads, and logo from the dashboard.
 * Version:           3.1.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Tested up to:      6.7
 * Stable tag:        3.1.0
 * Author:            Jagruti Belan
 * License:           GPL-2.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       landing-page-manager
 *
 * HOW TO SWITCH CONTENT TYPE:
 *   Go to WordPress Admin → Landing Page → Settings and choose a variant.
 */

defined( 'ABSPATH' ) || exit;

define( 'LPM_VERSION', '3.1.0' );
define( 'LPM_DIR',     plugin_dir_path( __FILE__ ) );
define( 'LPM_URL',     plugins_url( '/', __FILE__ ) );

// ── Admin Dashboard ───────────────────────────────────────────────────────────

if ( is_admin() ) {
    require_once LPM_DIR . 'admin/class-lpm-admin.php';
    LPM_Admin::init();
}

// Ensure leads table exists whenever the plugin is loaded (safe to run each time).
add_action( 'admin_init', 'lpm_maybe_create_leads_table' );

function lpm_maybe_create_leads_table(): void {
    if ( get_option( 'lpm_leads_db_version' ) !== '1.0' ) {
        lpm_create_leads_table();
    }
}

function lpm_create_leads_table(): void {
    global $wpdb;
    $table           = $wpdb->prefix . 'lpm_leads';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE {$table} (
        id         bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        variant    varchar(50)  NOT NULL DEFAULT '',
        name       varchar(200) NOT NULL DEFAULT '',
        email      varchar(200) NOT NULL DEFAULT '',
        phone      varchar(50)  NOT NULL DEFAULT '',
        message    text         NOT NULL,
        status     varchar(20)  NOT NULL DEFAULT 'new',
        created_at datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY status (status),
        KEY variant (variant),
        KEY created_at (created_at)
    ) {$charset_collate};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
    update_option( 'lpm_leads_db_version', '1.0' );
}

// ── Activation ────────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'lpm_activate' );

function lpm_activate() {
    update_option( 'lpm_orig_show_on_front',  get_option( 'show_on_front',  'posts' ) );
    update_option( 'lpm_orig_page_on_front',  get_option( 'page_on_front',  0 ) );
    update_option( 'lpm_orig_page_for_posts', get_option( 'page_for_posts', 0 ) );
    update_option( 'lpm_active', 1 );
    lpm_create_leads_table();
}

// ── Deactivation ──────────────────────────────────────────────────────────────

register_deactivation_hook( __FILE__, 'lpm_deactivate' );

function lpm_deactivate() {
    update_option( 'show_on_front',  get_option( 'lpm_orig_show_on_front',  'posts' ) );
    update_option( 'page_on_front',  get_option( 'lpm_orig_page_on_front',  0 ) );
    update_option( 'page_for_posts', get_option( 'lpm_orig_page_for_posts', 0 ) );

    delete_option( 'lpm_active' );
    delete_option( 'lpm_orig_show_on_front' );
    delete_option( 'lpm_orig_page_on_front' );
    delete_option( 'lpm_orig_page_for_posts' );
}

// ── Enqueue Assets ────────────────────────────────────────────────────────────

add_action( 'wp_enqueue_scripts', 'lpm_enqueue_assets' );

function lpm_enqueue_assets() {
    if ( ! get_option( 'lpm_active' ) || ! is_front_page() ) {
        return;
    }

    $config    = lpm_get_config();
    $site_type = sanitize_key( $config['site_type'] );

    // Google Fonts — Inter (all weights needed).
    wp_enqueue_style(
        'lpm-google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap',
        [],
        null
    );

    // Shared base styles (resets, CSS vars, components).
    wp_enqueue_style(
        'lpm-base',
        LPM_URL . 'assets/css/base.css',
        [ 'lpm-google-fonts' ],
        LPM_VERSION
    );

    // Variant-specific theme overrides.
    wp_enqueue_style(
        'lpm-theme',
        LPM_URL . "assets/css/{$site_type}.css",
        [ 'lpm-base' ],
        LPM_VERSION
    );

    // Shared JS — mobile nav, scroll effects, animations.
    wp_enqueue_script(
        'lpm-main',
        LPM_URL . 'assets/js/main.js',
        [],
        LPM_VERSION,
        true  // Load in footer.
    );
}

// ── Override Homepage Template ────────────────────────────────────────────────

add_action( 'template_redirect', 'lpm_override_homepage' );

function lpm_override_homepage() {
    if ( ! get_option( 'lpm_active' ) || ! is_front_page() ) {
        return;
    }

    $config    = lpm_get_config();
    $site_type = sanitize_key( $config['site_type'] );
    $template  = LPM_DIR . "templates/{$site_type}.php";

    if ( file_exists( $template ) ) {
        $data = $config[ $site_type ] ?? [];
        include $template;
        exit;
    }
}

// ── Contact Form Handler ──────────────────────────────────────────────────────

add_action( 'admin_post_nopriv_lpm_contact', 'lpm_handle_contact' );
add_action( 'admin_post_lpm_contact',        'lpm_handle_contact' );

function lpm_handle_contact() {
    $nonce = isset( $_POST['lpm_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['lpm_nonce'] ) ) : '';
    if ( ! wp_verify_nonce( $nonce, 'lpm_contact_form' ) ) {
        wp_die( esc_html__( 'Security check failed.', 'landing-page-manager' ) );
    }

    $redirect = wp_get_referer() ?: home_url( '/' );

    // Honeypot: bots fill hidden fields — real users never see or touch it.
    if ( ! empty( $_POST['lpm_hp'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        wp_safe_redirect( add_query_arg( 'lpm_status', 'success', $redirect ) );
        exit;
    }

    // Rate limit: max 1 submission per IP per 60 seconds.
    $ip_hash = md5( ( $_SERVER['REMOTE_ADDR'] ?? '' ) . ( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
    $rl_key  = 'lpm_rl_' . $ip_hash;
    if ( get_transient( $rl_key ) ) {
        wp_safe_redirect( add_query_arg( 'lpm_status', 'error', $redirect ) );
        exit;
    }

    $name    = sanitize_text_field( wp_unslash( $_POST['lpm_name']    ?? '' ) );
    $email   = sanitize_email(      wp_unslash( $_POST['lpm_email']   ?? '' ) );
    $phone   = sanitize_text_field( wp_unslash( $_POST['lpm_phone']   ?? '' ) );
    $message = sanitize_textarea_field( wp_unslash( $_POST['lpm_message'] ?? '' ) );
    $variant = sanitize_key( wp_unslash( $_POST['lpm_variant'] ?? 'unknown' ) );

    if ( empty( $name ) || ! is_email( $email ) || empty( $message ) ) {
        wp_safe_redirect( add_query_arg( 'lpm_status', 'error', $redirect ) );
        exit;
    }

    // Save as a lead in the database.
    global $wpdb;
    $wpdb->insert(
        $wpdb->prefix . 'lpm_leads',
        [
            'variant'    => $variant,
            'name'       => $name,
            'email'      => $email,
            'phone'      => $phone,
            'message'    => $message,
            'status'     => 'new',
            'created_at' => current_time( 'mysql' ),
        ],
        [ '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
    );

    // Set rate-limit transient after successful DB insert.
    set_transient( $rl_key, 1, 60 );

    // Also send email notification.
    $to      = get_option( 'admin_email' );
    $subject = sprintf( '[%s] New enquiry from %s', get_bloginfo( 'name' ), $name );
    $body    = "Name: {$name}\nEmail: {$email}" . ( $phone ? "\nPhone: {$phone}" : '' ) . "\n\nMessage:\n{$message}";
    $headers = [ "Reply-To: {$name} <{$email}>", 'Content-Type: text/plain; charset=UTF-8' ];

    wp_mail( $to, $subject, $body, $headers );

    wp_safe_redirect( add_query_arg( 'lpm_status', 'success', $redirect ) );
    exit;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Returns the full merged config (config.php defaults + WP options overrides).
 */
function lpm_get_config(): array {
    static $config = null;
    if ( null === $config ) {
        $defaults = include LPM_DIR . 'config.php';

        // Override site_type from WP options.
        $settings  = get_option( 'lpm_settings', [] );
        if ( ! empty( $settings['site_type'] ) ) {
            $defaults['site_type'] = sanitize_key( $settings['site_type'] );
        }

        // Merge saved yoga content over defaults.
        $yoga_saved = get_option( 'lpm_content_yoga', [] );
        if ( ! empty( $yoga_saved ) ) {
            $defaults['yoga'] = array_replace_recursive( $defaults['yoga'], $yoga_saved );
        }

        // Merge saved construction content over defaults.
        $const_saved = get_option( 'lpm_content_construction', [] );
        if ( ! empty( $const_saved ) ) {
            $defaults['construction'] = array_replace_recursive( $defaults['construction'], $const_saved );
        }

        // Merge saved hospital content over defaults.
        $hosp_saved = get_option( 'lpm_content_hospital', [] );
        if ( ! empty( $hosp_saved ) ) {
            $defaults['hospital'] = array_replace_recursive( $defaults['hospital'], $hosp_saved );
        }

        // Merge saved jewellery content over defaults.
        $jewel_saved = get_option( 'lpm_content_jewellery', [] );
        if ( ! empty( $jewel_saved ) ) {
            $defaults['jewellery'] = array_replace_recursive( $defaults['jewellery'], $jewel_saved );
        }

        $config = $defaults;
    }
    return $config;
}

/**
 * Clears the static config cache so changes take effect immediately.
 * Called after options are saved from the admin dashboard.
 */
function lpm_clear_config_cache(): void {
    // Access and null the static variable inside lpm_get_config.
    // Since PHP static vars can't be reset externally, we use a flag option.
    // The simplest reliable approach: use a transient as a cache-bust signal.
    delete_transient( 'lpm_config_cache' );
    // Also reset via include-cache break (PHP will re-evaluate the include
    // on next request because the static var belongs to the current request).
    // No action needed — static vars reset per-request automatically.
}

/**
 * Returns the raw config.php defaults for a specific variant.
 * Used in admin forms to pre-fill fields before saved options are overlaid.
 */
function lpm_get_defaults( string $variant ): array {
    $defaults = include LPM_DIR . 'config.php';
    return $defaults[ $variant ] ?? [];
}
