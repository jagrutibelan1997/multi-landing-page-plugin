<?php
/**
 * Landing Page Manager — Uninstall
 *
 * Runs automatically when the plugin is deleted from WordPress Admin → Plugins.
 * Drops the leads database table and removes all stored options.
 */

// Safety check: only run in a real WordPress uninstall context.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// Drop the leads table.
$table = $wpdb->prefix . 'lpm_leads';
$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared

// Remove all plugin options.
$options = [
    'lpm_active',
    'lpm_settings',
    'lpm_leads_db_version',
    'lpm_content_yoga',
    'lpm_content_construction',
    'lpm_content_hospital',
    'lpm_content_jewellery',
    'lpm_orig_show_on_front',
    'lpm_orig_page_on_front',
    'lpm_orig_page_for_posts',
];

foreach ( $options as $option ) {
    delete_option( $option );
}
