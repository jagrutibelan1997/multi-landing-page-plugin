<?php
/**
 * Landing Page Manager — Central Configuration
 * Author: Jagruti Belan
 *
 * Change $site_type below to: 'yoga' | 'construction' | 'hospital' | 'jewellery'
 */
defined( 'ABSPATH' ) || exit;

$site_type = 'yoga'; // ← CHANGE THIS: 'yoga' | 'construction' | 'hospital' | 'jewellery'

return [

    'site_type' => $site_type,

    // =========================================================================
    // YOGA
    // =========================================================================
    'yoga' => [

        'site_name'  => 'Serenity Yoga',
        'tagline'    => 'Find Your Balance',
        'logo_image' => '', // URL to logo image — leave empty to use emoji + site name
        'logo_text'  => '', // Custom nav display name — leave empty to use site_name

        'nav' => [
            [ 'label' => 'About',        'href' => '#about' ],
            [ 'label' => 'Benefits',     'href' => '#benefits' ],
            [ 'label' => 'Classes',      'href' => '#classes' ],
            [ 'label' => 'Testimonials', 'href' => '#testimonials' ],
            [ 'label' => 'Contact',      'href' => '#contact' ],
        ],

        'hero' => [
            'eyebrow'    => 'Welcome to Serenity Yoga Studio',
            'headline'   => 'Find Your Inner Peace',
            'subheading' => 'Certified instructors. All levels welcome. Transform your mind, body and soul through the ancient practice of yoga.',
            'cta_text'   => 'Join Now — First Class Free',
            'cta_url'    => '#contact',
            'cta2_text'  => 'View Classes',
            'cta2_url'   => '#classes',
            'bg_image'   => 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=1920&q=85',
        ],

        'about' => [
            'heading'  => 'More Than Exercise — It\'s a Lifestyle',
            'lead'     => 'Founded in 2010, Serenity Yoga has helped over 5,000 students discover balance, strength and mindfulness.',
            'text'     => 'Our welcoming studio offers a sanctuary for practitioners at every stage of their journey. With experienced, certified instructors and a warm community of like-minded people, you\'ll feel at home from your very first class.',
            'image'    => 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=900&q=85',
            'stats'    => [
                [ 'value' => '5,000+', 'label' => 'Students' ],
                [ 'value' => '15+',    'label' => 'Instructors' ],
                [ 'value' => '12',     'label' => 'Class Types' ],
            ],
        ],

        'benefits' => [
            'heading'  => 'Why Practise Yoga?',
            'subtext'  => 'Science-backed benefits that reach every aspect of your wellbeing.',
            'items'    => [
                [ 'icon' => '🧘', 'title' => 'Reduces Stress',     'text' => 'Calm your nervous system and lower cortisol levels naturally through breathwork and mindful movement.' ],
                [ 'icon' => '💪', 'title' => 'Builds Strength',    'text' => 'Tone muscles, improve posture and build core stability without any equipment.' ],
                [ 'icon' => '🌿', 'title' => 'Boosts Flexibility', 'text' => 'Progressively increase your range of motion and prevent common injuries from daily life.' ],
                [ 'icon' => '😴', 'title' => 'Better Sleep',       'text' => 'Evening yoga and meditation practices prime your body for a deep, restorative night\'s sleep.' ],
            ],
        ],

        'classes' => [
            'heading' => 'Our Classes',
            'subtext' => 'Something for everyone — from first-timers to advanced practitioners.',
            'items'   => [
                [
                    'name'  => 'Hatha Yoga',
                    'level' => 'Beginner',
                    'time'  => 'Mon & Wed · 7:00 AM',
                    'desc'  => 'Slow-paced, gentle poses focused on alignment and breathing.',
                    'image' => 'https://images.unsplash.com/photo-1588286840104-8957b019727f?w=600&q=80',
                ],
                [
                    'name'  => 'Vinyasa Flow',
                    'level' => 'Intermediate',
                    'time'  => 'Tue & Thu · 6:30 AM',
                    'desc'  => 'Dynamic sequences synchronized with breath for strength and focus.',
                    'image' => 'https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=600&q=80',
                ],
                [
                    'name'  => 'Yin Yoga',
                    'level' => 'All Levels',
                    'time'  => 'Fri & Sat · 8:00 AM',
                    'desc'  => 'Deep, meditative stretches held 3–5 minutes to release tension.',
                    'image' => 'https://images.unsplash.com/photo-1545389336-cf090694435e?w=600&q=80',
                ],
            ],
        ],

        'testimonials' => [
            'heading' => 'Loved by Our Community',
            'subtext' => 'Real stories from real students.',
            'items'   => [
                [ 'quote' => 'Serenity Yoga changed my life completely. I sleep better, feel stronger and face each day with genuine calm.', 'name' => 'Meera K.', 'role' => 'Student since 2021', 'avatar' => 'https://i.pravatar.cc/80?img=47' ],
                [ 'quote' => 'The instructors are world-class. I went from a total beginner to confidently doing headstands in just 3 months!', 'name' => 'Rahul D.', 'role' => 'Student since 2022', 'avatar' => 'https://i.pravatar.cc/80?img=12' ],
                [ 'quote' => 'Best investment I\'ve made in my health. The community here is warm, supportive and genuinely special.', 'name' => 'Sneha M.', 'role' => 'Student since 2020', 'avatar' => 'https://i.pravatar.cc/80?img=32' ],
            ],
        ],

        'contact' => [
            'heading' => 'Start Your Free Trial',
            'subtext' => 'Your first class is completely free. No experience needed.',
            'address' => '12 Lotus Lane, Pune, MH 411001',
            'email'   => 'hello@serenityyoga.com',
            'phone'   => '+91 98765 43210',
            'hours'   => 'Mon–Sat: 6 AM – 9 PM',
        ],
    ],

    // =========================================================================
    // CONSTRUCTION
    // =========================================================================
    'construction' => [

        'site_name'  => 'BuildRight Co.',
        'tagline'    => 'Built to Last',
        'logo_image' => '',
        'logo_text'  => '',

        'nav' => [
            [ 'label' => 'About',        'href' => '#about' ],
            [ 'label' => 'Services',     'href' => '#classes' ],
            [ 'label' => 'Why Us',       'href' => '#benefits' ],
            [ 'label' => 'Testimonials', 'href' => '#testimonials' ],
            [ 'label' => 'Contact',      'href' => '#contact' ],
        ],

        'hero' => [
            'eyebrow'    => 'Award-Winning Construction',
            'headline'   => 'Building Your Vision, Brick by Brick',
            'subheading' => 'Premium residential and commercial construction. Delivered on time, within budget, with uncompromising quality.',
            'cta_text'   => 'Get a Free Quote',
            'cta_url'    => '#contact',
            'cta2_text'  => 'Our Services',
            'cta2_url'   => '#classes',
            'bg_image'   => 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1920&q=85',
        ],

        'about' => [
            'heading'  => '20 Years of Building Excellence',
            'lead'     => 'BuildRight has delivered 500+ residential and commercial projects across the region since 2004.',
            'text'     => 'Our expert team of licensed engineers, architects and certified tradespeople handles every project from groundwork to final finishing. Transparent pricing, rigorous quality control and real accountability — on every build.',
            'image'    => 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=900&q=85',
            'stats'    => [
                [ 'value' => '500+', 'label' => 'Projects' ],
                [ 'value' => '20+',  'label' => 'Years' ],
                [ 'value' => '98%',  'label' => 'On-Time' ],
            ],
        ],

        'benefits' => [
            'heading'  => 'Why Choose BuildRight?',
            'subtext'  => 'We set the standard others measure themselves against.',
            'items'    => [
                [ 'icon' => '🏗️', 'title' => 'Expert Team',         'text' => 'Skilled engineers, licensed architects and certified tradespeople on every project.' ],
                [ 'icon' => '⏱️', 'title' => 'On-Time Delivery',    'text' => 'We commit to timelines and deliver on them — every single milestone.' ],
                [ 'icon' => '💰', 'title' => 'Transparent Pricing', 'text' => 'Detailed quotes with zero hidden costs. What we quote is what you pay.' ],
                [ 'icon' => '🏆', 'title' => 'Quality Guaranteed',  'text' => 'Premium materials and rigorous QA checks at every stage of your build.' ],
            ],
        ],

        'classes' => [
            'heading' => 'Our Services',
            'subtext' => 'From foundations to finishing touches — we do it all.',
            'items'   => [
                [
                    'name'  => 'Residential Builds',
                    'level' => 'Homes & Villas',
                    'time'  => 'Custom Timeline',
                    'desc'  => 'Custom homes, villas and apartments built to your exact specification.',
                    'image' => 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=600&q=80',
                ],
                [
                    'name'  => 'Commercial Projects',
                    'level' => 'Offices & Retail',
                    'time'  => 'Custom Timeline',
                    'desc'  => 'Office complexes, retail spaces and warehouses delivered at scale.',
                    'image' => 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&q=80',
                ],
                [
                    'name'  => 'Renovations',
                    'level' => 'Interior & Exterior',
                    'time'  => 'Flexible Schedule',
                    'desc'  => 'Full-scope renovations that modernise and add long-term value.',
                    'image' => 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&q=80',
                ],
            ],
        ],

        'testimonials' => [
            'heading' => 'What Our Clients Say',
            'subtext' => 'Trusted by homeowners and businesses across the region.',
            'items'   => [
                [ 'quote' => 'BuildRight completed our office complex two weeks early and under budget. The craftsmanship was exceptional throughout.', 'name' => 'Arjun S.', 'role' => 'CEO, TechVentures', 'avatar' => 'https://i.pravatar.cc/80?img=68' ],
                [ 'quote' => 'Our dream home was built exactly as we envisioned. Communication was transparent and professional every step of the way.', 'name' => 'Priya & Raj M.', 'role' => 'Homeowners', 'avatar' => 'https://i.pravatar.cc/80?img=23' ],
                [ 'quote' => 'Professional team, premium materials, real craftsmanship. We\'ve now used BuildRight for three successive projects.', 'name' => 'Vikram T.', 'role' => 'Property Developer', 'avatar' => 'https://i.pravatar.cc/80?img=55' ],
            ],
        ],

        'contact' => [
            'heading' => 'Get a Free Quote',
            'subtext' => 'Tell us about your project and we\'ll respond within 24 hours.',
            'address' => '45 Industrial Estate, Mumbai, MH 400001',
            'email'   => 'info@buildright.co.in',
            'phone'   => '+91 22 6789 0123',
            'hours'   => 'Mon–Sat: 8 AM – 6 PM',
        ],
    ],

    // =========================================================================
    // HOSPITAL
    // =========================================================================
    'hospital' => [

        'site_name'  => 'CarePoint Hospital',
        'tagline'    => 'Your Health, Our Priority',
        'logo_image' => '',
        'logo_text'  => '',

        'nav' => [
            [ 'label' => 'About',       'href' => '#about' ],
            [ 'label' => 'Departments', 'href' => '#classes' ],
            [ 'label' => 'Why Us',      'href' => '#benefits' ],
            [ 'label' => 'Reviews',     'href' => '#testimonials' ],
            [ 'label' => 'Contact',     'href' => '#contact' ],
        ],

        'hero' => [
            'eyebrow'    => 'NABH-Accredited Multi-Specialty Hospital',
            'headline'   => 'Compassionate Care, Advanced Medicine',
            'subheading' => 'Board-certified specialists. State-of-the-art diagnostics. Round-the-clock emergency services. Your family\'s health in trusted hands.',
            'cta_text'   => 'Book an Appointment',
            'cta_url'    => '#contact',
            'cta2_text'  => 'Our Departments',
            'cta2_url'   => '#classes',
            'bg_image'   => 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1920&q=85',
        ],

        'about' => [
            'heading'  => '25 Years of Healing, Hope & Excellence',
            'lead'     => 'Founded in 1999, CarePoint Hospital has served over 2,00,000 patients with compassion, clinical precision and cutting-edge technology.',
            'text'     => 'Our hospital brings together 150+ specialist doctors across 30 departments under one roof. Every patient receives personalised care guided by the latest evidence-based protocols in a warm, supportive environment.',
            'image'    => 'https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=900&q=85',
            'stats'    => [
                [ 'value' => '2,00,000+', 'label' => 'Patients Served' ],
                [ 'value' => '150+',      'label' => 'Specialist Doctors' ],
                [ 'value' => '500',       'label' => 'Beds' ],
            ],
        ],

        'benefits' => [
            'heading'  => 'Why Choose CarePoint?',
            'subtext'  => 'World-class care delivered with warmth and expertise.',
            'items'    => [
                [ 'icon' => '🚑', 'title' => '24/7 Emergency',      'text' => 'Fully-equipped emergency unit with rapid-response trauma and critical care teams round the clock.' ],
                [ 'icon' => '🩺', 'title' => 'Specialist Doctors',  'text' => 'Over 150 board-certified specialists covering every major discipline of modern medicine.' ],
                [ 'icon' => '🔬', 'title' => 'Advanced Diagnostics','text' => 'In-house MRI, CT, PET scan and a fully-automated pathology lab for same-day reports.' ],
                [ 'icon' => '💊', 'title' => 'Patient-First Care',   'text' => 'Dedicated care coordinators, multilingual staff and transparent billing for peace of mind.' ],
            ],
        ],

        'classes' => [
            'heading' => 'Our Departments',
            'subtext' => 'Comprehensive care across 30+ medical specialties.',
            'items'   => [
                [
                    'name'  => 'Cardiology',
                    'level' => 'Heart Care',
                    'time'  => 'Mon–Sat · 9 AM – 5 PM',
                    'desc'  => 'Advanced cardiac diagnostics, interventional procedures and cardiac rehabilitation programmes.',
                    'image' => 'https://images.unsplash.com/photo-1628348068343-c6a848d2b6dd?w=600&q=80',
                ],
                [
                    'name'  => 'Orthopaedics',
                    'level' => 'Bone & Joint',
                    'time'  => 'Mon–Sat · 9 AM – 5 PM',
                    'desc'  => 'Joint replacements, sports injuries, spine surgery and minimally-invasive procedures.',
                    'image' => 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=600&q=80',
                ],
                [
                    'name'  => 'Women & Child',
                    'level' => 'Gynaecology & Paediatrics',
                    'time'  => 'Mon–Sat · 9 AM – 7 PM',
                    'desc'  => 'Complete maternal care, high-risk pregnancy management and dedicated NICU.',
                    'image' => 'https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=600&q=80',
                ],
            ],
        ],

        'testimonials' => [
            'heading' => 'Patient Stories',
            'subtext' => 'Kind words from patients and their families.',
            'items'   => [
                [ 'quote' => 'The cardiac team at CarePoint saved my father\'s life during his heart attack. The response was swift and the care was exceptional.', 'name' => 'Rohit A.', 'role' => 'Patient\'s Son', 'avatar' => 'https://i.pravatar.cc/80?img=60' ],
                [ 'quote' => 'I delivered my baby at CarePoint. The gynaecology and NICU teams were simply outstanding. We felt completely safe and cared for.', 'name' => 'Ananya P.', 'role' => 'New Mother', 'avatar' => 'https://i.pravatar.cc/80?img=45' ],
                [ 'quote' => 'After my knee replacement surgery, the rehabilitation was seamless. I was back on my feet faster than expected. Brilliant ortho team!', 'name' => 'Suresh K.', 'role' => 'Knee Replacement Patient', 'avatar' => 'https://i.pravatar.cc/80?img=71' ],
            ],
        ],

        'contact' => [
            'heading' => 'Book an Appointment',
            'subtext' => 'Our care coordinators will confirm your appointment within 2 hours.',
            'address' => '7 Health Park, Bengaluru, KA 560001',
            'email'   => 'appointments@carepointhospital.in',
            'phone'   => '+91 80 4567 8900',
            'hours'   => 'OPD: Mon–Sat 8 AM – 8 PM | Emergency: 24/7',
        ],
    ],

    // =========================================================================
    // JEWELLERY
    // =========================================================================
    'jewellery' => [

        'site_name'  => 'Lumière Jewels',
        'tagline'    => 'Crafted for Eternity',
        'logo_image' => '',
        'logo_text'  => '',

        'nav' => [
            [ 'label' => 'About',       'href' => '#about' ],
            [ 'label' => 'Collections', 'href' => '#classes' ],
            [ 'label' => 'Why Us',      'href' => '#benefits' ],
            [ 'label' => 'Reviews',     'href' => '#testimonials' ],
            [ 'label' => 'Contact',     'href' => '#contact' ],
        ],

        'hero' => [
            'eyebrow'    => 'Handcrafted Fine Jewellery Since 1985',
            'headline'   => 'Where Every Piece Tells a Story',
            'subheading' => 'Certified diamonds, 22K & 18K gold, platinum and precious gemstones. Custom-designed jewellery crafted by master artisans with a lifetime guarantee.',
            'cta_text'   => 'Explore Collections',
            'cta_url'    => '#classes',
            'cta2_text'  => 'Book Appointment',
            'cta2_url'   => '#contact',
            'bg_image'   => 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1920&q=85',
        ],

        'about' => [
            'heading'  => 'Four Decades of Artisan Excellence',
            'lead'     => 'Established in 1985, Lumière Jewels has adorned over 50,000 families across three generations with heirloom-quality jewellery.',
            'text'     => 'Every piece leaving our atelier is the result of meticulous craftsmanship, ethically-sourced materials and a deep passion for beauty. Whether you\'re celebrating a milestone or creating a bespoke heirloom, we craft jewellery that lasts a lifetime and beyond.',
            'image'    => 'https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?w=900&q=85',
            'stats'    => [
                [ 'value' => '50,000+', 'label' => 'Happy Families' ],
                [ 'value' => '40+',     'label' => 'Years of Craft' ],
                [ 'value' => '10,000+', 'label' => 'Unique Designs' ],
            ],
        ],

        'benefits' => [
            'heading'  => 'The Lumière Promise',
            'subtext'  => 'Every piece comes with our signature guarantee of quality and authenticity.',
            'items'    => [
                [ 'icon' => '✋', 'title' => 'Handcrafted',          'text' => 'Each piece is individually crafted by our master artisans — never mass-produced, always unique.' ],
                [ 'icon' => '💎', 'title' => 'Certified Diamonds',   'text' => 'All diamonds are GIA-certified. Every stone is ethically sourced with full provenance documentation.' ],
                [ 'icon' => '✏️', 'title' => 'Custom Design',        'text' => 'Work directly with our in-house designers to create a completely bespoke piece just for you.' ],
                [ 'icon' => '🛡️', 'title' => 'Lifetime Warranty',   'text' => 'Free lifetime cleaning, polishing and minor repairs for every piece purchased from Lumière.' ],
            ],
        ],

        'classes' => [
            'heading' => 'Our Collections',
            'subtext' => 'Timeless designs for every occasion and every story.',
            'items'   => [
                [
                    'name'  => 'Bridal Collection',
                    'level' => 'Wedding & Engagement',
                    'time'  => 'Visit by Appointment',
                    'desc'  => 'Exquisite bridal sets, solitaire engagement rings and mangalsutra crafted in 22K gold and platinum.',
                    'image' => 'https://images.unsplash.com/photo-1604176354204-9268737828e4?w=600&q=80',
                ],
                [
                    'name'  => 'Everyday Elegance',
                    'level' => 'Daily Wear',
                    'time'  => 'In-store & Online',
                    'desc'  => 'Lightweight gold chains, hoops, studs and delicate bracelets designed for everyday radiance.',
                    'image' => 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&q=80',
                ],
                [
                    'name'  => 'Statement Gems',
                    'level' => 'Precious Stones',
                    'time'  => 'In-store Only',
                    'desc'  => 'Rubies, emeralds, sapphires and certified diamonds set in hand-crafted 18K gold and platinum.',
                    'image' => 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&q=80',
                ],
            ],
        ],

        'testimonials' => [
            'heading' => 'Stories of Joy',
            'subtext' => 'A small glimpse of the love we help create.',
            'items'   => [
                [ 'quote' => 'Lumière designed our wedding rings completely from scratch. The result was beyond breathtaking. Every guest asked where they came from!', 'name' => 'Kavya & Arjun', 'role' => 'Newlyweds', 'avatar' => 'https://i.pravatar.cc/80?img=25' ],
                [ 'quote' => 'I bought my mother a diamond pendant for her 60th birthday. The craftsmanship was flawless and the presentation was absolutely stunning.', 'name' => 'Nisha R.', 'role' => 'Customer since 2019', 'avatar' => 'https://i.pravatar.cc/80?img=41' ],
                [ 'quote' => 'The team helped me design a custom necklace with my grandmother\'s old gold. The transformation was magical. Truly priceless craftsmanship.', 'name' => 'Deepa M.', 'role' => 'Customer since 2021', 'avatar' => 'https://i.pravatar.cc/80?img=36' ],
            ],
        ],

        'contact' => [
            'heading' => 'Visit Our Atelier',
            'subtext' => 'Book a private appointment for a personalised jewellery consultation.',
            'address' => '3 Gold Souk, Ahmedabad, GJ 380001',
            'email'   => 'hello@lumierejewels.in',
            'phone'   => '+91 79 2634 5678',
            'hours'   => 'Mon–Sat: 10 AM – 8 PM | Sun: 11 AM – 6 PM',
        ],
    ],
];
