/**
 * Landing Page Manager — Main JS
 * Theme toggle · Mobile nav · Scroll effects · Animations
 * Author: Jagruti Belan
 */
(function () {
  'use strict';

  // ── Theme Toggle (dark/light) ───────────────────────────────── //
  var themeKey = 'lpm_theme';
  var body = document.body;
  var toggleBtn = document.querySelector('.lpm-theme-toggle');

  function getStoredTheme() {
    try { return localStorage.getItem(themeKey); } catch (e) { return null; }
  }

  function setTheme(theme) {
    body.setAttribute('data-theme', theme);
    try { localStorage.setItem(themeKey, theme); } catch (e) {}
    if (toggleBtn) {
      toggleBtn.textContent = theme === 'dark' ? '\u2600\uFE0F' : '\uD83C\uDF19';
      toggleBtn.setAttribute('aria-label', 'Switch to ' + (theme === 'dark' ? 'light' : 'dark') + ' mode');
    }
  }

  // Initialize theme — default dark.
  var stored = getStoredTheme();
  setTheme(stored || 'dark');

  if (toggleBtn) {
    toggleBtn.addEventListener('click', function () {
      var current = body.getAttribute('data-theme') || 'dark';
      setTheme(current === 'dark' ? 'light' : 'dark');
    });
  }

  // ── Mobile Navigation ───────────────────────────────────────── //
  var nav    = document.querySelector('.lpm-nav');
  var toggle = document.querySelector('.lpm-nav__toggle');
  var menu   = document.querySelector('.lpm-nav__links');

  if (toggle && menu) {
    toggle.addEventListener('click', function () {
      var open = menu.classList.toggle('is-open');
      toggle.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
      document.body.style.overflow = open ? 'hidden' : '';
    });

    menu.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        menu.classList.remove('is-open');
        toggle.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });

    document.addEventListener('click', function (e) {
      if (nav && !nav.contains(e.target) && menu.classList.contains('is-open')) {
        menu.classList.remove('is-open');
        toggle.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      }
    });
  }

  // ── Nav shadow on scroll ────────────────────────────────────── //
  if (nav) {
    var onScroll = function () {
      nav.classList.toggle('is-scrolled', window.scrollY > 20);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  // ── Smooth Scroll ───────────────────────────────────────────── //
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var id     = this.getAttribute('href');
      var target = id === '#' ? null : document.querySelector(id);
      if (!target) return;
      e.preventDefault();
      var navHeight = nav ? nav.offsetHeight : 0;
      var top       = target.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
      window.scrollTo({ top: top, behavior: 'smooth' });
    });
  });

  // ── Scroll-reveal ───────────────────────────────────────────── //
  var revealEls = document.querySelectorAll('.lpm-reveal');

  if (revealEls.length && 'IntersectionObserver' in window) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('is-visible'); });
  }

  // ── Active nav link ─────────────────────────────────────────── //
  var sections = document.querySelectorAll('section[id]');
  var navLinks = document.querySelectorAll('.lpm-nav__links a[href^="#"]');

  if (sections.length && navLinks.length) {
    var highlightNav = function () {
      var scrollY    = window.pageYOffset;
      var navHeight  = nav ? nav.offsetHeight : 72;
      var activeHref = '';

      sections.forEach(function (section) {
        var top = section.offsetTop - navHeight - 40;
        if (scrollY >= top) { activeHref = '#' + section.id; }
      });

      navLinks.forEach(function (link) {
        link.classList.toggle('is-active', link.getAttribute('href') === activeHref);
      });
    };

    window.addEventListener('scroll', highlightNav, { passive: true });
    highlightNav();
  }

  // ── Form validation ─────────────────────────────────────────── //
  var form = document.querySelector('.lpm-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      var valid = true;

      form.querySelectorAll('[required]').forEach(function (field) {
        field.classList.remove('lpm-field--error');
        if (!field.value.trim()) { field.classList.add('lpm-field--error'); valid = false; }
        if (field.type === 'email' && field.value.trim()) {
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value.trim())) {
            field.classList.add('lpm-field--error'); valid = false;
          }
        }
      });

      if (!valid) {
        e.preventDefault();
        var firstError = form.querySelector('.lpm-field--error');
        if (firstError) { firstError.focus(); firstError.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
      }
    });

    form.querySelectorAll('[required]').forEach(function (field) {
      field.addEventListener('input', function () { this.classList.remove('lpm-field--error'); });
    });
  }

}());
